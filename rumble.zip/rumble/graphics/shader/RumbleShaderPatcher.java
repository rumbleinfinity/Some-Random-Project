package com.rumble.graphics.shader;

import com.rumble.graphics.RumbleGraphics;
import com.rumble.graphics.config.RumbleConfig;
import net.minecraft.resources.ResourceLocation;

import java.util.Locale;

/**
 * Injects the RumbleGraphics shaders suite into Sodium chunk shaders:
 * - Waving foliage exclusively for plants (grass, flowers, crops) & gentle leaf canopy sway
 * - Zero deformation for solid blocks (dirt, stone, terrain never opens seams)
 * - Crystal clear natural water with animated ripple waves, fresnel, and sunlight shimmer
 * - Dynamic skylight shadows with high contrast & deep contact ambient occlusion
 */
public class RumbleShaderPatcher {

    private static volatile boolean vertexShaderPatched = false;
    private static volatile boolean fragmentShaderPatched = false;

    public static String patch(ResourceLocation name, String source) {
        if (name == null || source == null) {
            return source;
        }

        RumbleConfig config = RumbleConfig.get();
        if (!config.masterEnabled) {
            return source; // Master switch is OFF: return 100% clean vanilla Sodium shader
        }

        try {
            String path = name.getPath();
            if (path.endsWith("block_layer_opaque.vsh")) {
                return patchVertexShader(source, config);
            } else if (path.endsWith("block_layer_opaque.fsh")) {
                return patchFragmentShader(source, config);
            }
        } catch (Throwable t) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Defensive shader patch failed: ", t);
        }

        return source;
    }

    private static String patchVertexShader(String source, RumbleConfig config) {
        String targetOut = "out vec2 v_TexCoord;";
        String replacementOut = "out vec2 v_TexCoord;\n"
                + "out vec2 v_RumbleLight;\n"
                + "out vec3 v_RumblePos;\n"
                + "uniform float u_RumbleTime;\n"
                + "uniform int u_RumbleWaving;\n"
                + "uniform int u_RumblePass;";

        String targetAssign = "v_TexCoord = (_vert_tex_diffuse_coord_bias * u_TexCoordShrink) + _vert_tex_diffuse_coord;";
        String replacementAssign = targetAssign + "\n"
                + "    v_RumbleLight = _vert_tex_light_coord;\n"
                + "    v_RumblePos = position;\n";

        String targetGlPos = "gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * vec4(position, 1.0);";
        String wavingLogic = "    #ifdef USE_FRAGMENT_DISCARD\n"
                + "    if (u_RumbleWaving == 1) {\n"
                + "        float plantHeight = clamp(fract(position.y + 0.02), 0.0, 1.0);\n"
                + "        float waveWeight = smoothstep(0.12, 0.95, plantHeight);\n"
                + "        float t = u_RumbleTime * 2.2;\n"
                + "        float windX = sin(t + position.x * 0.75 + position.z * 0.55) * 0.07\n"
                + "                    + sin(t * 1.5 + position.x * 1.3 - position.z * 0.9) * 0.035;\n"
                + "        float windZ = cos(t * 0.9 + position.x * 0.6 - position.z * 0.8) * 0.05;\n"
                + "        position.x += windX * waveWeight;\n"
                + "        position.z += windZ * waveWeight;\n"
                + "    }\n"
                + "    #endif\n"
                + "    gl_Position = u_ProjectionMatrix * u_ModelViewMatrix * vec4(position, 1.0);";

        if (source.contains(targetOut) && source.contains(targetAssign) && source.contains(targetGlPos)) {
            source = source.replace(targetOut, replacementOut);
            source = source.replace(targetAssign, replacementAssign);
            source = source.replace(targetGlPos, wavingLogic);
            vertexShaderPatched = true;
            RumbleGraphics.LOGGER.info("[RumbleGraphics] Successfully patched Vertex Shader with Waving Foliage!");
        } else {
            RumbleGraphics.LOGGER.warn("[RumbleGraphics] Failed to find injection points in Vertex Shader! Original source preserved.");
        }

        return source;
    }

    private static String patchFragmentShader(String source, RumbleConfig config) {
        String targetIn = "in vec2 v_TexCoord;";
        String replacementIn = "in vec2 v_TexCoord;\n"
                + "in vec2 v_RumbleLight;\n"
                + "in vec3 v_RumblePos;\n"
                + "uniform float u_RumbleTime;\n"
                + "uniform int u_RumbleWater;\n"
                + "uniform int u_RumblePass;";

        String targetLighting = "    // Apply per-vertex color\n"
                + "    diffuseColor.rgb *= v_Color.rgb;\n\n"
                + "    // Apply ambient occlusion \"shade\"\n"
                + "    diffuseColor.rgb *= v_Color.a;";

        float shadowIntensity = Math.max(0.1f, Math.min(1.0f, config.shadowIntensity / 100.0f));
        String shadowStr = String.format(Locale.ROOT, "%.2f", shadowIntensity);

        StringBuilder sbLighting = new StringBuilder();
        sbLighting.append("    // === RumbleGraphics Dynamic Mobile Lighting & Shadows ===\n");
        sbLighting.append("    float skyLight = clamp(v_RumbleLight.y, 0.0, 1.0);\n");
        sbLighting.append("    float blockLight = clamp(v_RumbleLight.x, 0.0, 1.0);\n\n");

        // 1. Shadows & Directional Sunlight (High Contrast Skylight)
        if (config.enableSkylightShadows) {
            sbLighting.append("    // Direct sunlight (warm gold) vs shade under trees/cliffs (cool blue ambient)\n");
            sbLighting.append("    float sunExposure = smoothstep(0.40, 0.95, skyLight);\n");
            sbLighting.append("    vec3 directSunColor = vec3(1.18, 1.10, 0.95);\n");
            sbLighting.append("    vec3 ambientShadowColor = vec3(0.55, 0.65, 0.88);\n");
            sbLighting.append("    vec3 dynamicTone = mix(ambientShadowColor, directSunColor, sunExposure);\n");
            sbLighting.append("    dynamicTone += vec3(0.38, 0.20, -0.05) * (blockLight * blockLight);\n");
            sbLighting.append("    dynamicTone = mix(vec3(1.0), dynamicTone, ").append(shadowStr).append(");\n\n");
        } else {
            sbLighting.append("    vec3 dynamicTone = vec3(1.0);\n\n");
        }

        // 2. Deep Contact AO
        if (config.enableContactAO) {
            sbLighting.append("    float rawAO = clamp(v_Color.a, 0.0, 1.0);\n");
            sbLighting.append("    float deepAO = pow(rawAO, 1.8 + ").append(shadowStr).append(" * 0.8);\n");
            sbLighting.append("    float contactShadow = mix(rawAO, deepAO, ").append(shadowStr).append(" * 0.9);\n\n");
        } else {
            sbLighting.append("    float contactShadow = v_Color.a;\n\n");
        }

        sbLighting.append("    diffuseColor.rgb *= v_Color.rgb;\n");
        sbLighting.append("    diffuseColor.rgb *= contactShadow;\n");
        sbLighting.append("    diffuseColor.rgb *= dynamicTone;\n\n");

        // 3. Realistic Water in Translucent Pass (pass == 2)
        sbLighting.append("    // --- Rumble Enhanced Water ---\n");
        sbLighting.append("    if (u_RumblePass == 2 && u_RumbleWater == 1) {\n");
        sbLighting.append("        if (v_Color.b > v_Color.r + 0.02 && diffuseColor.a > 0.20 && diffuseColor.a < 0.98) {\n");
        sbLighting.append("            float t = u_RumbleTime * 1.6;\n");
        sbLighting.append("            vec2 wuv1 = v_RumblePos.xz * 0.40 + vec2(t * 0.04, t * 0.025);\n");
        sbLighting.append("            vec2 wuv2 = v_RumblePos.xz * 0.70 - vec2(t * 0.03, -t * 0.05);\n");
        sbLighting.append("            float ripple = sin(wuv1.x * 2.0 + wuv1.y * 1.5) * 0.5 + sin(wuv2.x * 1.8 - wuv2.y * 2.2) * 0.5;\n");
        sbLighting.append("            vec3 waterDeepColor = vec3(0.06, 0.42, 0.68);\n");
        sbLighting.append("            diffuseColor.rgb = mix(diffuseColor.rgb, waterDeepColor, 0.35);\n");
        sbLighting.append("            diffuseColor.rgb += vec3(0.06, 0.10, 0.14) * ripple;\n");
        sbLighting.append("            vec3 viewDir = normalize(-v_RumblePos);\n");
        sbLighting.append("            float fresnel = pow(1.0 - max(viewDir.y, 0.0), 3.0);\n");
        sbLighting.append("            vec3 skyReflectColor = vec3(0.60, 0.80, 1.0);\n");
        sbLighting.append("            diffuseColor.rgb = mix(diffuseColor.rgb, skyReflectColor, fresnel * 0.38);\n");
        sbLighting.append("            vec3 sunDir = normalize(vec3(0.45, 0.80, 0.38));\n");
        sbLighting.append("            vec3 halfVec = normalize(sunDir + viewDir);\n");
        sbLighting.append("            vec3 waterNorm = normalize(vec3(-ripple * 0.05, 1.0, -ripple * 0.05));\n");
        sbLighting.append("            float spec = pow(max(dot(waterNorm, halfVec), 0.0), 48.0);\n");
        sbLighting.append("            float sunFactor = smoothstep(0.50, 0.95, skyLight);\n");
        sbLighting.append("            diffuseColor.rgb += vec3(1.0, 0.92, 0.75) * (spec * 0.55 * sunFactor);\n");
        sbLighting.append("            diffuseColor.a = clamp(diffuseColor.a * 0.85, 0.45, 0.80);\n");
        sbLighting.append("        }\n");
        sbLighting.append("    }\n");

        if (source.contains(targetIn) && source.contains(targetLighting)) {
            source = source.replace(targetIn, replacementIn);
            source = source.replace(targetLighting, sbLighting.toString());
            fragmentShaderPatched = true;
            RumbleGraphics.LOGGER.info("[RumbleGraphics] Successfully patched Fragment Shader with Shadows & Water!");
        } else {
            RumbleGraphics.LOGGER.warn("[RumbleGraphics] Failed to find injection points in Fragment Shader! Original source preserved.");
        }

        return source;
    }

    public static boolean isVertexShaderPatched() {
        return vertexShaderPatched;
    }

    public static boolean isFragmentShaderPatched() {
        return fragmentShaderPatched;
    }
}
