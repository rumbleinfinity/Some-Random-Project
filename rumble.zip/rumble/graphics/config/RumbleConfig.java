package com.rumble.graphics.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.rumble.graphics.RumbleGraphics;
import net.fabricmc.loader.api.FabricLoader;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * Configuration settings for RumbleGraphics mobile graphics extension.
 * Persists to config/rumblegraphics.json
 */
public class RumbleConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final File CONFIG_FILE = new File(FabricLoader.getInstance().getConfigDir().toFile(), "rumblegraphics.json");

    private static RumbleConfig INSTANCE = new RumbleConfig();

    // --- Master Control ---
    /** Master switch to turn the entire mod ON or OFF */
    public boolean masterEnabled = true;

    /** Quality Preset: 0 = Custom, 1 = Low, 2 = Medium, 3 = High (Adreno 740) */
    public int qualityPreset = 3;

    // --- Tab 1: Super Resolution & Render Scale ---
    /** 3D Internal Render Scale: 50%, 67%, 75%, 90%, 100% (Native) */
    public int renderScale = 100;

    /** Enable Edge-Adaptive Sharpening (EACS) */
    public boolean enableSnapdragonGSR = true;

    /** GSR Edge sharpness percentage (10 to 100 percent -> maps to 1.0 - 3.5) */
    public int gsrSharpness = 75;

    /** GSR Edge sensitivity percentage (10 to 100 percent) */
    public int gsrSensitivity = 70;

    /** Hardware optimization: Always active (hidden from GUI) */
    public boolean mobileGluesOptimized = true;

    // --- Tab 2: Lighting & Atmosphere ---
    /** Atmospheric crepuscular sun godrays */
    public boolean enableGodrays = true;

    /** Godray intensity factor (10 to 100 percent) */
    public int godrayIntensity = 50;

    /** Godray raymarching step count (8=Low, 12=Medium, 16=High, 20=Ultra) */
    public int godrayQuality = 12;

    /** Godray downscale factor (2 = Half Resolution, 4 = Quarter Resolution) */
    public int godrayDownscale = 4;

    /** Soft bloom glow around bright block lights and sun */
    public boolean enableBloom = true;

    /** Bloom glow strength (10 to 100 percent) */
    public int bloomIntensity = 70;

    /** Bloom bright-pass threshold (20 to 90 percent) - 45% captures torches, lava, lanterns */
    public int bloomThreshold = 45;

    /** Multi-scale Bloom pyramid quality (2=Low, 3=Medium, 4=High levels) */
    public int bloomQuality = 3;

    /** Cinematic optical lens flare when facing the sun */
    public boolean enableLensFlare = true;

    /** Lens flare overall intensity factor (10 to 100 percent) */
    public int lensFlareIntensity = 35;

    /** Lens flare halo/corona intensity (10 to 100 percent) */
    public int lensFlareHaloIntensity = 30;

    /** Lens flare chromatic ghost disc intensity (10 to 100 percent) */
    public int lensFlareGhostIntensity = 25;

    /** Lens flare anamorphic streak intensity (10 to 100 percent) */
    public int lensFlareStreakIntensity = 25;

    /** Color vibrance boost */
    public boolean enableVibrance = true;

    /** Color grading: Exposure adjustment (50 to 150 percent, 100 = neutral) */
    public int colorExposure = 100;

    /** Color grading: Contrast adjustment (50 to 150 percent, 104 = rich crisp contrast) */
    public int colorContrast = 104;

    /** Color grading: Saturation adjustment (50 to 150 percent, 108 = pleasant vividness) */
    public int colorSaturation = 108;

    /** Color grading: Color Temperature / Warmth (50 = cool/blue, 100 = neutral, 102 = warm sunlight) */
    public int colorTemperature = 102;

    /** Filmic ACES Tonemapping for smooth high-dynamic-range highlights */
    public boolean enableTonemapping = true;

    // --- Tab 3: Volumetric Clouds ---
    /** Screen-space layered volumetric clouds */
    public boolean enableClouds = false;

    /** Cloud density (10 to 100 percent) */
    public int cloudDensity = 50;

    /** Cloud raymarching quality (1 = Low 6 steps, 2 = Med 8 steps, 3 = High 12 steps) */
    public int cloudQuality = 2;

    /** Cloud wind speed (10 to 100 percent) */
    public int cloudSpeed = 50;

    // --- Tab 4: Foliage & Water ---
    /** Waving foliage: grass, tall grass, leaves, flowers, crops */
    public boolean enableWaving = true;

    /** Enhanced water transparency, procedural waves, and sunlight reflection */
    public boolean enableWater = true;

    /** Deep contact ambient occlusion (crevice shadows) */
    public boolean enableContactAO = true;

    /** Atmospheric skylight directional shading */
    public boolean enableSkylightShadows = true;

    /** Shadow depth factor (10 to 100 percent) */
    public int shadowIntensity = 80;

    // --- Tab 5: Visual Debug System ---
    /**
     * Visual Debug Mode:
     * 0 = Disabled (Normal beauty composite)
     * 1 = Original Scene (unmodified vanilla passthrough)
     * 2 = Bloom Extraction Only
     * 3 = Bloom Blur Only (pyramid output)
     * 4 = Godrays Only (isolated on black)
     * 5 = Sun Tracker Position Marker
     * 6 = Sun Occlusion Visualization
     * 7 = Sharpening Edge Contrast Map
     * 8 = Color Grading Only (no bloom/godrays)
     * 9 = Volumetric Clouds Only
     * 10 = Split Screen (Left = Original, Right = RumbleGraphics)
     */
    public int debugMode = 0;

    /** Show on-screen real-time diagnostic debug HUD */
    public boolean showDebugHud = false;

    public void applyPreset(int preset) {
        this.qualityPreset = preset;
        switch (preset) {
            case 1 -> { // LOW
                this.renderScale = 75;
                this.enableSnapdragonGSR = true;
                this.gsrSharpness = 50;
                this.enableBloom = true;
                this.bloomIntensity = 50;
                this.bloomThreshold = 55;
                this.bloomQuality = 2;
                this.enableGodrays = false;
                this.godrayIntensity = 40;
                this.godrayQuality = 8;
                this.godrayDownscale = 4;
                this.enableLensFlare = false;
                this.enableClouds = false;
                this.enableWaving = false;
                this.enableWater = true;
                this.enableContactAO = false;
                this.enableSkylightShadows = false;
                this.enableTonemapping = true;
                this.colorContrast = 102;
                this.colorSaturation = 104;
            }
            case 2 -> { // MEDIUM
                this.renderScale = 90;
                this.enableSnapdragonGSR = true;
                this.gsrSharpness = 70;
                this.enableBloom = true;
                this.bloomIntensity = 65;
                this.bloomThreshold = 48;
                this.bloomQuality = 3;
                this.enableGodrays = true;
                this.godrayIntensity = 50;
                this.godrayQuality = 10;
                this.godrayDownscale = 4;
                this.enableLensFlare = true;
                this.lensFlareIntensity = 30;
                this.enableClouds = false;
                this.enableWaving = true;
                this.enableWater = true;
                this.enableContactAO = true;
                this.enableSkylightShadows = true;
                this.shadowIntensity = 70;
                this.enableTonemapping = true;
                this.colorContrast = 104;
                this.colorSaturation = 106;
            }
            case 3 -> { // HIGH (Engineered for Snapdragon 8 Gen 2 / Adreno 740)
                this.renderScale = 100;
                this.enableSnapdragonGSR = true;
                this.gsrSharpness = 75;
                this.enableBloom = true;
                this.bloomIntensity = 70;
                this.bloomThreshold = 45;
                this.bloomQuality = 3;
                this.enableGodrays = true;
                this.godrayIntensity = 50;
                this.godrayQuality = 14;
                this.godrayDownscale = 4;
                this.enableLensFlare = true;
                this.lensFlareIntensity = 35;
                this.lensFlareHaloIntensity = 30;
                this.lensFlareGhostIntensity = 25;
                this.lensFlareStreakIntensity = 25;
                this.enableClouds = false;
                this.enableWaving = true;
                this.enableWater = true;
                this.enableContactAO = true;
                this.enableSkylightShadows = true;
                this.shadowIntensity = 80;
                this.enableTonemapping = true;
                this.colorContrast = 104;
                this.colorSaturation = 108;
                this.colorTemperature = 102;
            }
        }
    }

    public static RumbleConfig get() {
        return INSTANCE;
    }

    public static void load() {
        if (CONFIG_FILE.exists()) {
            try (FileReader reader = new FileReader(CONFIG_FILE)) {
                RumbleConfig config = GSON.fromJson(reader, RumbleConfig.class);
                if (config != null) {
                    INSTANCE = config;
                    RumbleGraphics.LOGGER.info("[RumbleGraphics] Loaded config from rumblegraphics.json");
                }
            } catch (Exception e) {
                RumbleGraphics.LOGGER.error("[RumbleGraphics] Failed to load config file: ", e);
            }
        } else {
            save();
        }
    }

    public static void save() {
        try (FileWriter writer = new FileWriter(CONFIG_FILE)) {
            GSON.toJson(INSTANCE, writer);
            RumbleGraphics.LOGGER.info("[RumbleGraphics] Saved config to rumblegraphics.json");
        } catch (Exception e) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Failed to save config file: ", e);
        }
    }
}
