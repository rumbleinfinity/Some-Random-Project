package com.rumble.graphics.mixin;

import com.rumble.graphics.shader.RumbleShaderPatcher;
import me.jellysquid.mods.sodium.client.gl.shader.ShaderLoader;
import net.minecraft.resources.ResourceLocation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ShaderLoader.class)
public class ShaderLoaderMixin {

    @Inject(method = "getShaderSource", at = @At("RETURN"), cancellable = true)
    private static void onGetShaderSource(ResourceLocation name, CallbackInfoReturnable<String> cir) {
        String originalSource = cir.getReturnValue();
        if (originalSource != null) {
            String patched = RumbleShaderPatcher.patch(name, originalSource);
            cir.setReturnValue(patched);
        }
    }
}
