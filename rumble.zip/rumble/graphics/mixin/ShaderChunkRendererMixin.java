package com.rumble.graphics.mixin;

import com.rumble.graphics.config.RumbleConfig;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import me.jellysquid.mods.sodium.client.gl.shader.GlProgram;
import me.jellysquid.mods.sodium.client.render.chunk.ShaderChunkRenderer;
import me.jellysquid.mods.sodium.client.render.chunk.shader.ChunkShaderInterface;
import me.jellysquid.mods.sodium.client.render.chunk.terrain.TerrainRenderPass;
import org.lwjgl.opengl.GL20;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin to pass real-time uniform parameters (time, pass type, waving toggle, water toggle)
 * to Sodium's chunk shaders for 60+ FPS waving foliage, waving leaves, and flowing water.
 * Uses cached uniform locations to avoid driver overhead during chunk rendering.
 */
@Mixin(ShaderChunkRenderer.class)
public class ShaderChunkRendererMixin {

    @Shadow(remap = false)
    protected GlProgram<ChunkShaderInterface> activeProgram;

    @Unique
    private static final Int2ObjectOpenHashMap<UniformCache> rumble$cacheMap = new Int2ObjectOpenHashMap<>();

    @Unique
    private static volatile String rumble$lastPassName = "None";

    @Unique
    private static volatile boolean rumble$sodiumActive = false;

    @Inject(method = "begin", at = @At("TAIL"), remap = false)
    private void onBegin(TerrainRenderPass pass, CallbackInfo ci) {
        RumbleConfig config = RumbleConfig.get();
        if (!config.masterEnabled) {
            rumble$sodiumActive = false;
            return;
        }

        if (this.activeProgram != null) {
            rumble$sodiumActive = true;
            int programId = this.activeProgram.handle();
            UniformCache cache = rumble$cacheMap.computeIfAbsent(programId, UniformCache::query);

            float time = (float) ((System.currentTimeMillis() % 10000000L) / 1000.0);
            int passType = pass.isReverseOrder() ? 2 : (pass.supportsFragmentDiscard() ? 1 : 0);

            if (pass.isReverseOrder()) {
                rumble$lastPassName = "TRANSLUCENT";
            } else if (pass.supportsFragmentDiscard()) {
                rumble$lastPassName = "CUTOUT";
            } else {
                rumble$lastPassName = "SOLID";
            }

            if (cache.locTime != -1) GL20.glUniform1f(cache.locTime, time);
            if (cache.locPass != -1) GL20.glUniform1i(cache.locPass, passType);
            if (cache.locWaving != -1) GL20.glUniform1i(cache.locWaving, config.enableWaving ? 1 : 0);
            if (cache.locWater != -1) GL20.glUniform1i(cache.locWater, config.enableWater ? 1 : 0);
        }
    }

    public static String getRumbleLastPassName() {
        return rumble$lastPassName;
    }

    public static boolean isRumbleSodiumActive() {
        return rumble$sodiumActive;
    }

    @Unique
    private static class UniformCache {
        final int locTime;
        final int locPass;
        final int locWaving;
        final int locWater;

        UniformCache(int locTime, int locPass, int locWaving, int locWater) {
            this.locTime = locTime;
            this.locPass = locPass;
            this.locWaving = locWaving;
            this.locWater = locWater;
        }

        static UniformCache query(int programId) {
            int t = GL20.glGetUniformLocation(programId, "u_RumbleTime");
            int p = GL20.glGetUniformLocation(programId, "u_RumblePass");
            int w = GL20.glGetUniformLocation(programId, "u_RumbleWaving");
            int wt = GL20.glGetUniformLocation(programId, "u_RumbleWater");
            return new UniformCache(t, p, w, wt);
        }
    }
}
