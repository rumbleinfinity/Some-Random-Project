package com.rumble.graphics.mixin;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.rumble.graphics.gsr.RenderScaleManager;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Intercepts Minecraft's main render target during 3D level rendering when
 * internal resolution scaling is active. Redirects all world rendering (terrain, sky, entities)
 * to RenderScaleManager's scaled target while leaving 2D GUI and HUD rendering at 100% native resolution.
 */
@Mixin(Minecraft.class)
public class MinecraftMixin {

    @Inject(method = "getMainRenderTarget", at = @At("HEAD"), cancellable = true)
    private void rumble$redirectMainRenderTarget(CallbackInfoReturnable<RenderTarget> cir) {
        if (RenderScaleManager.isScaleActive()) {
            RenderTarget target = RenderScaleManager.getScaledTarget();
            if (target != null) {
                cir.setReturnValue(target);
            }
        }
    }
}
