package com.rumble.graphics.mixin;

import com.rumble.graphics.gsr.RenderScaleManager;
import com.rumble.graphics.sun.SunTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Shadow
    @Final
    Minecraft minecraft;

    @Unique
    private static volatile long rumble$renderHookCalls = 0;

    /**
     * Intercepts Minecraft's active 3D world projection matrix before any 2D ortho/blit calls occur.
     */
    @Inject(method = "resetProjectionMatrix", at = @At("HEAD"))
    private void onResetProjectionMatrix(Matrix4f matrix4f, CallbackInfo ci) {
        if (matrix4f != null) {
            SunTracker.setCapturedProjectionMatrix(matrix4f);
        }
    }

    /**
     * Redirects level rendering to scaled render target if renderScale < 100%.
     */
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;renderLevel(FJLcom/mojang/blaze3d/vertex/PoseStack;)V", shift = At.Shift.BEFORE))
    private void onBeforeRenderLevel(float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        RenderScaleManager.beginLevelRender(this.minecraft);
    }

    /**
     * Executes post-processing pipeline and EASU reconstruction upscaling to native target.
     */
    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/LevelRenderer;doEntityOutline()V", shift = At.Shift.AFTER))
    private void onAfterRenderLevel(float tickDelta, long startTime, boolean tick, CallbackInfo ci) {
        rumble$renderHookCalls++;
        RenderScaleManager.endLevelRender(this.minecraft, tickDelta);
    }

    public static long getRumbleRenderHookCalls() {
        return rumble$renderHookCalls;
    }
}
