package com.rumble.graphics.gsr;

import com.mojang.blaze3d.platform.GlStateManager;
import com.rumble.graphics.RumbleGraphics;
import com.rumble.graphics.sun.SunTracker;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.nio.ByteBuffer;

/**
 * Lightweight Screen-Space Volumetric Clouds engineered for Snapdragon 8 Gen 2 / Adreno 740.
 * Rendered at 1/4 resolution, strictly masked by depth buffer so clouds never overwrite
 * terrain, trees, water, particles, or the player hand.
 */
public class VolumetricClouds {

    private int fboClouds = 0;
    private int texClouds = 0;
    private int currentWidth = 0;
    private int currentHeight = 0;

    private int cloudProgram = 0;

    private int locDepthSampler = -1;
    private int locUseDepthTexture = -1;
    private int locSunDirection = -1;
    private int locSunVisibility = -1;
    private int locTime = -1;
    private int locDensity = -1;
    private int locQuality = -1;
    private int locSpeed = -1;

    private boolean initialized = false;
    private boolean failed = false;

    private static final String VERTEX_SRC = "#version 330 core\n"
            + "layout(location = 0) in vec2 inPosition;\n"
            + "layout(location = 1) in vec2 inTexCoord;\n"
            + "out vec2 texCoord;\n"
            + "void main() {\n"
            + "    texCoord = inTexCoord;\n"
            + "    gl_Position = vec4(inPosition, 0.0, 1.0);\n"
            + "}\n";

    private static final String CLOUD_FRAGMENT_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "\n"
            + "uniform sampler2D DepthSampler;\n"
            + "uniform int UseDepthTexture;\n"
            + "uniform vec3 SunDirection;\n"
            + "uniform float SunVisibility;\n"
            + "uniform float Time;\n"
            + "uniform float Density;\n"
            + "uniform int Quality;\n" // 1=6 steps, 2=8 steps, 3=12 steps
            + "uniform float Speed;\n"
            + "\n"
            + "float hash(vec2 p) {\n"
            + "    vec3 p3 = fract(vec3(p.xyx) * 0.1031);\n"
            + "    p3 += dot(p3, p3.yzx + 33.33);\n"
            + "    return fract((p3.x + p3.y) * p3.z);\n"
            + "}\n"
            + "\n"
            + "float noise2D(vec2 p) {\n"
            + "    vec2 i = floor(p);\n"
            + "    vec2 f = fract(p);\n"
            + "    vec2 u = f * f * (3.0 - 2.0 * f);\n"
            + "    return mix(mix(hash(i + vec2(0.0, 0.0)), hash(i + vec2(1.0, 0.0)), u.x),\n"
            + "               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);\n"
            + "}\n"
            + "\n"
            + "float fbm2D(vec2 p) {\n"
            + "    float v = 0.0;\n"
            + "    v += 0.500 * noise2D(p); p *= 2.02;\n"
            + "    v += 0.250 * noise2D(p); p *= 2.03;\n"
            + "    v += 0.125 * noise2D(p);\n"
            + "    return v * 1.14;\n"
            + "}\n"
            + "\n"
            + "void main() {\n"
            + "    // Strict depth mask: only open sky (depth >= 0.9999) receives clouds\n"
            + "    if (UseDepthTexture == 1) {\n"
            + "        float d = texture(DepthSampler, texCoord).r;\n"
            + "        if (d < 0.9999) {\n"
            + "            fragColor = vec4(0.0);\n"
            + "            return;\n"
            + "        }\n"
            + "    }\n"
            + "\n"
            + "    vec2 uv = (texCoord - 0.5) * 2.0;\n"
            + "    float horizon = smoothstep(-0.25, 0.35, uv.y);\n"
            + "    if (horizon <= 0.01) {\n"
            + "        fragColor = vec4(0.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // Project to flat celestial cloud plane\n"
            + "    float planeDist = 1.0 / max(0.12, uv.y + 0.35);\n"
            + "    vec2 cloudUV = vec2(uv.x * planeDist * 0.55, planeDist * 0.75);\n"
            + "    vec2 wind = vec2(Time * Speed * 0.012, Time * Speed * 0.004);\n"
            + "    cloudUV += wind;\n"
            + "\n"
            + "    int steps = (Quality == 1) ? 6 : ((Quality == 2) ? 8 : 12);\n"
            + "    float accumDensity = 0.0;\n"
            + "    float stepSize = 0.035;\n"
            + "\n"
            + "    for (int i = 0; i < 12; i++) {\n"
            + "        if (i >= steps) break;\n"
            + "        vec2 samplePos = cloudUV + vec2(float(i) * 0.016 * SunDirection.x, float(i) * 0.016 * SunDirection.y);\n"
            + "        float n = fbm2D(samplePos * 1.6);\n"
            + "        float shape = smoothstep(0.42, 0.78, n);\n"
            + "        accumDensity += shape * stepSize;\n"
            + "    }\n"
            + "\n"
            + "    accumDensity *= (Density * 10.0);\n"
            + "    float alpha = clamp(1.0 - exp(-accumDensity), 0.0, 0.85) * horizon;\n"
            + "\n"
            + "    // Atmospheric sunlight scattering & ambient sky tint\n"
            + "    vec3 sunLight = vec3(1.15, 1.05, 0.95);\n"
            + "    vec3 ambientSky = vec3(0.72, 0.80, 0.92);\n"
            + "\n"
            + "    float sunAlignment = max(0.0, dot(vec3(uv.x, uv.y, 0.8), normalize(SunDirection)));\n"
            + "    float phase = mix(0.45, 1.15, pow(sunAlignment, 3.0));\n"
            + "\n"
            + "    vec3 cloudColor = mix(ambientSky, sunLight * phase, 0.40);\n"
            + "    fragColor = vec4(cloudColor * alpha, alpha);\n"
            + "}\n";

    public void init() {
        if (initialized || failed) return;

        cloudProgram = compileProgram(VERTEX_SRC, CLOUD_FRAGMENT_SRC);
        if (cloudProgram == 0) {
            failed = true;
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Failed to compile VolumetricClouds shader!");
            return;
        }

        locDepthSampler = GL20.glGetUniformLocation(cloudProgram, "DepthSampler");
        locUseDepthTexture = GL20.glGetUniformLocation(cloudProgram, "UseDepthTexture");
        locSunDirection = GL20.glGetUniformLocation(cloudProgram, "SunDirection");
        locSunVisibility = GL20.glGetUniformLocation(cloudProgram, "SunVisibility");
        locTime = GL20.glGetUniformLocation(cloudProgram, "Time");
        locDensity = GL20.glGetUniformLocation(cloudProgram, "Density");
        locQuality = GL20.glGetUniformLocation(cloudProgram, "Quality");
        locSpeed = GL20.glGetUniformLocation(cloudProgram, "Speed");

        initialized = true;
    }

    public void checkResize(int baseWidth, int baseHeight) {
        int w = Math.max(1, baseWidth / 4);
        int h = Math.max(1, baseHeight / 4);

        if (w == currentWidth && h == currentHeight && fboClouds != 0) {
            return;
        }

        destroyBuffers();

        currentWidth = w;
        currentHeight = h;

        texClouds = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texClouds);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (ByteBuffer) null);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);

        fboClouds = GL30.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboClouds);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, texClouds, 0);
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Cloud FBO incomplete! Status: {}", status);
        }
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
    }

    public int render(int depthTexId, boolean useDepth, int baseWidth, int baseHeight,
                      SunTracker sunTracker, float sunVisibility, float density, int quality, float speed, int quadVao) {
        if (!initialized) {
            init();
            if (failed) return 0;
        }

        checkResize(baseWidth, baseHeight);
        if (fboClouds == 0 || texClouds == 0) return 0;

        // Prepare fullscreen pass states
        GlStateManager._disableDepthTest();
        GlStateManager._depthMask(false);
        GlStateManager._disableBlend();
        GlStateManager._disableCull();
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glColorMask(true, true, true, true);

        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboClouds);
        GlStateManager._viewport(0, 0, currentWidth, currentHeight);

        GL20.glUseProgram(cloudProgram);

        float time = (float) ((System.currentTimeMillis() % 10000000L) / 1000.0);

        if (locSunDirection != -1) GL20.glUniform3f(locSunDirection, (float) sunTracker.getSunDirX(), (float) sunTracker.getSunDirY(), (float) sunTracker.getSunDirZ());
        if (locSunVisibility != -1) GL20.glUniform1f(locSunVisibility, sunVisibility);
        if (locTime != -1) GL20.glUniform1f(locTime, time);
        if (locDensity != -1) GL20.glUniform1f(locDensity, density);
        if (locQuality != -1) GL20.glUniform1i(locQuality, quality);
        if (locSpeed != -1) GL20.glUniform1f(locSpeed, speed);

        if (useDepth && depthTexId > 0 && GL11.glIsTexture(depthTexId)) {
            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexId);
            if (locDepthSampler != -1) GL20.glUniform1i(locDepthSampler, 0);
            if (locUseDepthTexture != -1) GL20.glUniform1i(locUseDepthTexture, 1);
        } else {
            if (locUseDepthTexture != -1) GL20.glUniform1i(locUseDepthTexture, 0);
        }

        GL30.glBindVertexArray(quadVao);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
        GL30.glBindVertexArray(0);

        GL20.glUseProgram(0);
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);

        return texClouds;
    }

    public int getTextureId() {
        return texClouds;
    }

    public void destroyBuffers() {
        if (fboClouds != 0) {
            GL30.glDeleteFramebuffers(fboClouds);
            fboClouds = 0;
        }
        if (texClouds != 0) {
            GL11.glDeleteTextures(texClouds);
            texClouds = 0;
        }
        currentWidth = 0;
        currentHeight = 0;
    }

    public void destroy() {
        destroyBuffers();
        if (cloudProgram != 0) {
            GL20.glDeleteProgram(cloudProgram);
            cloudProgram = 0;
        }
        initialized = false;
        failed = false;
    }

    private static int compileProgram(String vertSrc, String fragSrc) {
        int vert = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vert, vertSrc);
        GL20.glCompileShader(vert);
        if (GL20.glGetShaderi(vert, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Cloud Vert Shader Error: {}", GL20.glGetShaderInfoLog(vert));
            GL20.glDeleteShader(vert);
            return 0;
        }

        int frag = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(frag, fragSrc);
        GL20.glCompileShader(frag);
        if (GL20.glGetShaderi(frag, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Cloud Frag Shader Error: {}", GL20.glGetShaderInfoLog(frag));
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            return 0;
        }

        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vert);
        GL20.glAttachShader(prog, frag);
        GL20.glLinkProgram(prog);

        GL20.glDeleteShader(vert);
        GL20.glDeleteShader(frag);

        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Cloud Program Link Error: {}", GL20.glGetProgramInfoLog(prog));
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }
}
