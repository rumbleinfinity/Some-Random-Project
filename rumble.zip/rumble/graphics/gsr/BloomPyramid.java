package com.rumble.graphics.gsr;

import com.mojang.blaze3d.platform.GlStateManager;
import com.rumble.graphics.RumbleGraphics;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.nio.ByteBuffer;

/**
 * True Multi-Scale Kawase & Dual-Filtering Bloom Pyramid for mobile Adreno 740.
 * Architecture:
 * 1. Bright-pass Extraction with Soft-Knee Threshold (Level 0: W/2 x H/2)
 * 2. Downsample Pyramid (L1: W/4, L2: W/8, L3: W/16)
 * 3. Multi-pass Kawase Blur on lowest level
 * 4. Progressive 9-tap Tent Filter Upsampling & Additive Combine back to Level 0
 * 5. Returns final composite bloom texture to blend into the main post-processing shader
 */
public class BloomPyramid {

    private static final int MAX_LEVELS = 4;

    private final int[] fboDown = new int[MAX_LEVELS];
    private final int[] texDown = new int[MAX_LEVELS];
    private final int[] fboUp = new int[MAX_LEVELS];
    private final int[] texUp = new int[MAX_LEVELS];

    private final int[] levelWidth = new int[MAX_LEVELS];
    private final int[] levelHeight = new int[MAX_LEVELS];

    private int currentBaseWidth = 0;
    private int currentBaseHeight = 0;

    private int brightPassProgram = 0;
    private int downsampleProgram = 0;
    private int kawaseProgram = 0;
    private int upsampleProgram = 0;

    // Uniform locations for Bright-Pass
    private int locBpDiffuse = -1;
    private int locBpTexelSize = -1;
    private int locBpThreshold = -1;
    private int locBpSoftKnee = -1;

    // Uniform locations for Downsample
    private int locDsSource = -1;
    private int locDsTexelSize = -1;

    // Uniform locations for Kawase Blur
    private int locKwSource = -1;
    private int locKwTexelSize = -1;
    private int locKwOffset = -1;

    // Uniform locations for Upsample & Combine
    private int locUsCurrent = -1;
    private int locUsLower = -1;
    private int locUsLowerTexelSize = -1;
    private int locUsBloomWeight = -1;

    private boolean initialized = false;
    private boolean failed = false;

    private static final String VERTEX_SRC = "#version 330 core\n"
            + "layout(location = 0) in vec2 inPosition;\n"
            + "layout(location = 1) in vec2 inTexCoord;\n"
            + "out vec2 texCoord;\n"
            + "void main() {\n"
            + "    texCoord = inTexCoord;\n"
            + "    gl_Position = vec4(inPosition, 0.0, 1.0);\n"
            + "}\n";

    private static final String BRIGHT_PASS_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "uniform sampler2D DiffuseSampler;\n"
            + "uniform vec2 TexelSize;\n"
            + "uniform float Threshold;\n"
            + "uniform float SoftKnee;\n"
            + "void main() {\n"
            + "    vec2 o = TexelSize * 0.5;\n"
            + "    vec3 c = (texture(DiffuseSampler, texCoord + vec2(-o.x, -o.y)).rgb +\n"
            + "              texture(DiffuseSampler, texCoord + vec2( o.x, -o.y)).rgb +\n"
            + "              texture(DiffuseSampler, texCoord + vec2(-o.x,  o.y)).rgb +\n"
            + "              texture(DiffuseSampler, texCoord + vec2( o.x,  o.y)).rgb) * 0.25;\n"
            + "    float lum = dot(c, vec3(0.2126, 0.7152, 0.0722));\n"
            + "    float knee = max(0.001, Threshold * SoftKnee);\n"
            + "    float soft = lum - Threshold + knee;\n"
            + "    soft = clamp(soft, 0.0, 2.0 * knee);\n"
            + "    soft = (soft * soft) / (4.0 * knee);\n"
            + "    float weight = max(soft, lum - Threshold) / max(lum, 0.0001);\n"
            + "    fragColor = vec4(c * clamp(weight, 0.0, 1.0), 1.0);\n"
            + "}\n";

    private static final String DOWNSAMPLE_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "uniform sampler2D SourceTex;\n"
            + "uniform vec2 TexelSize;\n"
            + "void main() {\n"
            + "    vec2 o = TexelSize * 0.5;\n"
            + "    vec3 d = (texture(SourceTex, texCoord + vec2(-o.x, -o.y)).rgb +\n"
            + "              texture(SourceTex, texCoord + vec2( o.x, -o.y)).rgb +\n"
            + "              texture(SourceTex, texCoord + vec2(-o.x,  o.y)).rgb +\n"
            + "              texture(SourceTex, texCoord + vec2( o.x,  o.y)).rgb) * 0.25;\n"
            + "    fragColor = vec4(d, 1.0);\n"
            + "}\n";

    private static final String KAWASE_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "uniform sampler2D SourceTex;\n"
            + "uniform vec2 TexelSize;\n"
            + "uniform float Offset;\n"
            + "void main() {\n"
            + "    vec2 o = TexelSize * (Offset + 0.5);\n"
            + "    vec3 col = (texture(SourceTex, texCoord + vec2(-o.x, -o.y)).rgb +\n"
            + "                texture(SourceTex, texCoord + vec2( o.x, -o.y)).rgb +\n"
            + "                texture(SourceTex, texCoord + vec2(-o.x,  o.y)).rgb +\n"
            + "                texture(SourceTex, texCoord + vec2( o.x,  o.y)).rgb) * 0.25;\n"
            + "    fragColor = vec4(col, 1.0);\n"
            + "}\n";

    private static final String UPSAMPLE_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "uniform sampler2D CurrentLevelTex;\n"
            + "uniform sampler2D LowerLevelTex;\n"
            + "uniform vec2 LowerTexelSize;\n"
            + "uniform float BloomWeight;\n"
            + "void main() {\n"
            + "    vec2 o = LowerTexelSize;\n"
            + "    vec3 lower = texture(LowerLevelTex, texCoord).rgb * 4.0;\n"
            + "    lower += (texture(LowerLevelTex, texCoord + vec2(-o.x,  0.0)).rgb +\n"
            + "              texture(LowerLevelTex, texCoord + vec2( o.x,  0.0)).rgb +\n"
            + "              texture(LowerLevelTex, texCoord + vec2( 0.0, -o.y)).rgb +\n"
            + "              texture(LowerLevelTex, texCoord + vec2( 0.0,  o.y)).rgb) * 2.0;\n"
            + "    lower += (texture(LowerLevelTex, texCoord + vec2(-o.x, -o.y)).rgb +\n"
            + "              texture(LowerLevelTex, texCoord + vec2( o.x, -o.y)).rgb +\n"
            + "              texture(LowerLevelTex, texCoord + vec2(-o.x,  o.y)).rgb +\n"
            + "              texture(LowerLevelTex, texCoord + vec2( o.x,  o.y)).rgb) * 1.0;\n"
            + "    lower *= (1.0 / 16.0);\n"
            + "    vec3 current = texture(CurrentLevelTex, texCoord).rgb;\n"
            + "    fragColor = vec4(current + lower * BloomWeight, 1.0);\n"
            + "}\n";

    public void init() {
        if (initialized || failed) return;

        brightPassProgram = compileProgram(VERTEX_SRC, BRIGHT_PASS_SRC);
        downsampleProgram = compileProgram(VERTEX_SRC, DOWNSAMPLE_SRC);
        kawaseProgram = compileProgram(VERTEX_SRC, KAWASE_SRC);
        upsampleProgram = compileProgram(VERTEX_SRC, UPSAMPLE_SRC);

        if (brightPassProgram == 0 || downsampleProgram == 0 || kawaseProgram == 0 || upsampleProgram == 0) {
            failed = true;
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Failed to compile Multi-Scale Bloom shaders!");
            return;
        }

        // Query uniforms
        locBpDiffuse = GL20.glGetUniformLocation(brightPassProgram, "DiffuseSampler");
        locBpTexelSize = GL20.glGetUniformLocation(brightPassProgram, "TexelSize");
        locBpThreshold = GL20.glGetUniformLocation(brightPassProgram, "Threshold");
        locBpSoftKnee = GL20.glGetUniformLocation(brightPassProgram, "SoftKnee");

        locDsSource = GL20.glGetUniformLocation(downsampleProgram, "SourceTex");
        locDsTexelSize = GL20.glGetUniformLocation(downsampleProgram, "TexelSize");

        locKwSource = GL20.glGetUniformLocation(kawaseProgram, "SourceTex");
        locKwTexelSize = GL20.glGetUniformLocation(kawaseProgram, "TexelSize");
        locKwOffset = GL20.glGetUniformLocation(kawaseProgram, "Offset");

        locUsCurrent = GL20.glGetUniformLocation(upsampleProgram, "CurrentLevelTex");
        locUsLower = GL20.glGetUniformLocation(upsampleProgram, "LowerLevelTex");
        locUsLowerTexelSize = GL20.glGetUniformLocation(upsampleProgram, "LowerTexelSize");
        locUsBloomWeight = GL20.glGetUniformLocation(upsampleProgram, "BloomWeight");

        initialized = true;
    }

    public void checkResize(int width, int height) {
        if (width == currentBaseWidth && height == currentBaseHeight && fboDown[0] != 0) {
            return;
        }

        destroyBuffers();

        currentBaseWidth = width;
        currentBaseHeight = height;

        int curW = Math.max(1, width / 2);
        int curH = Math.max(1, height / 2);

        for (int i = 0; i < MAX_LEVELS; i++) {
            levelWidth[i] = curW;
            levelHeight[i] = curH;

            // Generate textures and FBOs for Down pyramid
            texDown[i] = createTexture(curW, curH);
            fboDown[i] = createFramebuffer(texDown[i]);

            // Generate textures and FBOs for Up pyramid
            texUp[i] = createTexture(curW, curH);
            fboUp[i] = createFramebuffer(texUp[i]);

            curW = Math.max(1, curW / 2);
            curH = Math.max(1, curH / 2);
        }
    }

    private int createTexture(int w, int h) {
        int tex = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, tex);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (ByteBuffer) null);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);
        return tex;
    }

    private int createFramebuffer(int textureId) {
        int fbo = GL30.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, textureId, 0);
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Bloom FBO incomplete! Status: {}", status);
        }
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
        return fbo;
    }

    /**
     * Executes the Multi-Scale Bloom Pyramid pass.
     * @return Texture ID of the final combined bloom at Level 0 (W/2 x H/2).
     */
    public int process(int sourceColorTex, int width, int height, float threshold, int quadVao, int qualityPreset) {
        if (!initialized) {
            init();
            if (failed) return 0;
        }

        checkResize(width, height);
        if (fboDown[0] == 0 || texDown[0] == 0) return 0;

        // Number of active pyramid levels based on quality preset
        // 1 = Low (2 levels), 2 = Medium (3 levels), 3 = High (4 levels)
        int activeLevels = clamp(qualityPreset, 2, MAX_LEVELS);

        // Crucial for Adreno 740 / Turnip: reset lingering Minecraft states
        GlStateManager._disableDepthTest();
        GlStateManager._depthMask(false);
        GlStateManager._disableBlend();
        GlStateManager._disableCull();
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glColorMask(true, true, true, true);

        GL30.glBindVertexArray(quadVao);

        // ========================================================
        // PASS 1: Bright-Pass Extraction (Source -> fboDown[0])
        // ========================================================
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboDown[0]);
        GlStateManager._viewport(0, 0, levelWidth[0], levelHeight[0]);
        GL20.glUseProgram(brightPassProgram);

        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, sourceColorTex);
        if (locBpDiffuse != -1) GL20.glUniform1i(locBpDiffuse, 0);
        if (locBpTexelSize != -1) GL20.glUniform2f(locBpTexelSize, 1.0f / width, 1.0f / height);
        if (locBpThreshold != -1) GL20.glUniform1f(locBpThreshold, threshold);
        if (locBpSoftKnee != -1) GL20.glUniform1f(locBpSoftKnee, 0.50f);

        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);

        // ========================================================
        // PASS 2: Downsample Pyramid (Level i-1 -> Level i)
        // ========================================================
        GL20.glUseProgram(downsampleProgram);
        if (locDsSource != -1) GL20.glUniform1i(locDsSource, 0);

        for (int i = 1; i < activeLevels; i++) {
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboDown[i]);
            GlStateManager._viewport(0, 0, levelWidth[i], levelHeight[i]);

            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, texDown[i - 1]);
            if (locDsTexelSize != -1) {
                GL20.glUniform2f(locDsTexelSize, 1.0f / levelWidth[i - 1], 1.0f / levelHeight[i - 1]);
            }

            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
        }

        // ========================================================
        // PASS 3: Multi-Pass Kawase Blur on Lowest Level
        // ========================================================
        int lowest = activeLevels - 1;
        int currentLowestTex = texDown[lowest];

        GL20.glUseProgram(kawaseProgram);
        if (locKwSource != -1) GL20.glUniform1i(locKwSource, 0);
        if (locKwTexelSize != -1) {
            GL20.glUniform2f(locKwTexelSize, 1.0f / levelWidth[lowest], 1.0f / levelHeight[lowest]);
        }

        int blurPasses = (qualityPreset >= 3) ? 2 : 1;
        for (int pass = 0; pass < blurPasses; pass++) {
            int targetFbo = (pass % 2 == 0) ? fboUp[lowest] : fboDown[lowest];
            int inputTex = (pass % 2 == 0) ? texDown[lowest] : texUp[lowest];

            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, targetFbo);
            GlStateManager._viewport(0, 0, levelWidth[lowest], levelHeight[lowest]);

            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, inputTex);
            if (locKwOffset != -1) GL20.glUniform1f(locKwOffset, (float) pass + 1.2f);

            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
            currentLowestTex = (pass % 2 == 0) ? texUp[lowest] : texDown[lowest];
        }

        int lastUpsampleTex = currentLowestTex;

        // ========================================================
        // PASS 4: Progressive 9-Tap Upsample & Additive Combine
        // ========================================================
        GL20.glUseProgram(upsampleProgram);
        if (locUsCurrent != -1) GL20.glUniform1i(locUsCurrent, 0);
        if (locUsLower != -1) GL20.glUniform1i(locUsLower, 1);
        if (locUsBloomWeight != -1) GL20.glUniform1f(locUsBloomWeight, 0.85f);

        for (int i = lowest - 1; i >= 0; i--) {
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboUp[i]);
            GlStateManager._viewport(0, 0, levelWidth[i], levelHeight[i]);

            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, texDown[i]);

            GL13.glActiveTexture(GL13.GL_TEXTURE1);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, lastUpsampleTex);

            if (locUsLowerTexelSize != -1) {
                GL20.glUniform2f(locUsLowerTexelSize, 1.0f / levelWidth[i + 1], 1.0f / levelHeight[i + 1]);
            }

            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
            lastUpsampleTex = texUp[i];
        }

        GL30.glBindVertexArray(0);
        GL20.glUseProgram(0);

        // Returns level 0 upsample texture ID (finely filtered, smooth multi-scale bloom)
        return texUp[0];
    }

    /**
     * Returns raw bright-pass extraction texture ID for Debug Mode 2.
     */
    public int getExtractionTextureId() {
        return texDown[0];
    }

    public void destroyBuffers() {
        for (int i = 0; i < MAX_LEVELS; i++) {
            if (fboDown[i] != 0) {
                GL30.glDeleteFramebuffers(fboDown[i]);
                fboDown[i] = 0;
            }
            if (texDown[i] != 0) {
                GL11.glDeleteTextures(texDown[i]);
                texDown[i] = 0;
            }
            if (fboUp[i] != 0) {
                GL30.glDeleteFramebuffers(fboUp[i]);
                fboUp[i] = 0;
            }
            if (texUp[i] != 0) {
                GL11.glDeleteTextures(texUp[i]);
                texUp[i] = 0;
            }
        }
        currentBaseWidth = 0;
        currentBaseHeight = 0;
    }

    public void destroy() {
        destroyBuffers();
        if (brightPassProgram != 0) {
            GL20.glDeleteProgram(brightPassProgram);
            brightPassProgram = 0;
        }
        if (downsampleProgram != 0) {
            GL20.glDeleteProgram(downsampleProgram);
            downsampleProgram = 0;
        }
        if (kawaseProgram != 0) {
            GL20.glDeleteProgram(kawaseProgram);
            kawaseProgram = 0;
        }
        if (upsampleProgram != 0) {
            GL20.glDeleteProgram(upsampleProgram);
            upsampleProgram = 0;
        }
        initialized = false;
        failed = false;
    }

    private static int compileProgram(String vertSrc, String fragSrc) {
        int vert = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vert, vertSrc);
        GL20.glCompileShader(vert);
        if (GL20.glGetShaderi(vert, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Bloom Vert Shader Error: {}", GL20.glGetShaderInfoLog(vert));
            GL20.glDeleteShader(vert);
            return 0;
        }

        int frag = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(frag, fragSrc);
        GL20.glCompileShader(frag);
        if (GL20.glGetShaderi(frag, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Bloom Frag Shader Error: {}", GL20.glGetShaderInfoLog(frag));
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            return 0;
        }

        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vert);
        GL20.glAttachShader(prog, frag);
        GL20.glLinkProgram(prog);

        GL20.glDeleteShader(vert);
        GL20.glDeleteShader(frag);

        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Bloom Program Link Error: {}", GL20.glGetProgramInfoLog(prog));
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }

    private static int clamp(int val, int min, int max) {
        return Math.max(min, Math.min(max, val));
    }
}
