package com.rumble.graphics.gsr;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.rumble.graphics.RumbleGraphics;
import com.rumble.graphics.config.RumbleConfig;
import com.rumble.graphics.gl.GLStateManagerHelper;
import com.rumble.graphics.sun.SunOcclusion;
import com.rumble.graphics.sun.SunTracker;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;

/**
 * High-performance Post-Processing Pipeline engineered for Snapdragon 8 Gen 2 / Adreno 740.
 * Architecture:
 * - Edge-Adaptive Contrast Sharpening (EACS) with Anti-Ringing
 * - True Multi-Scale Kawase & Dual-Filtering Bloom Pyramid (BloomPyramid)
 * - Decoupled Low-Resolution Crepuscular Rays (GodrayPass at 1/4 res)
 * - Screen-Space Layered Volumetric Clouds (VolumetricClouds at 1/4 res)
 * - Cinematic Optical Lens Flare with Preserved Sun Disc & Independent Controls
 * - Photographic Color Grading (Exposure, Contrast, Saturation, Vibrance, Warmth)
 * - Normalized ACES Filmic Tonemapping
 * - Comprehensive 11-mode Visual Debug Suite
 */
public class PostProcessPipeline {

    private static final GLStateManagerHelper glState = new GLStateManagerHelper();
    private static final SunTracker sunTracker = new SunTracker();
    private static final SunOcclusion sunOcclusion = new SunOcclusion();
    private static final BloomPyramid bloomPyramid = new BloomPyramid();
    private static final GodrayPass godrayPass = new GodrayPass();
    private static final VolumetricClouds volumetricClouds = new VolumetricClouds();

    private static int postProcessProgramId = 0;
    private static int copyProgramId = 0;
    private static int quadVao = 0;
    private static int quadVbo = 0;

    // Uniform locations for Post-Processing Shader
    private static int locViewportInfo = -1;
    private static int locSunInfo = -1;
    private static int locDiffuseSampler = -1;
    private static int locBloomSampler = -1;
    private static int locGodraySampler = -1;
    private static int locCloudSampler = -1;
    private static int locDepthSampler = -1;
    private static int locUseDepthTexture = -1;
    private static int locDebugMode = -1;

    private static int locEnableSharpening = -1;
    private static int locSharpness = -1;
    private static int locEdgeThreshold = -1;

    private static int locEnableBloom = -1;
    private static int locBloomIntensity = -1;

    private static int locEnableGodrays = -1;
    private static int locGodrayIntensity = -1;

    private static int locEnableLensFlare = -1;
    private static int locLensFlareIntensity = -1;
    private static int locLensFlareHalo = -1;
    private static int locLensFlareGhost = -1;
    private static int locLensFlareStreak = -1;

    private static int locEnableClouds = -1;

    private static int locEnableColorGrading = -1;
    private static int locExposure = -1;
    private static int locContrast = -1;
    private static int locSaturation = -1;
    private static int locVibrance = -1;
    private static int locColorTemperature = -1;

    private static int locEnableTonemapping = -1;

    // Uniform location for Copy Shader
    private static int locCopyDiffuseSampler = -1;

    private static TextureTarget secondaryTarget = null;
    private static boolean initialized = false;
    private static boolean failed = false;

    // Diagnostic runtime metrics
    private static long frameCount = 0;
    private static int lastWidth = 0;
    private static int lastHeight = 0;
    private static boolean pipelineActiveLastFrame = false;
    private static long lastExecutionNanos = 0;

    private static final String VERTEX_SRC = "#version 330 core\n"
            + "layout(location = 0) in vec2 inPosition;\n"
            + "layout(location = 1) in vec2 inTexCoord;\n"
            + "out vec2 texCoord;\n"
            + "void main() {\n"
            + "    texCoord = inTexCoord;\n"
            + "    gl_Position = vec4(inPosition, 0.0, 1.0);\n"
            + "}\n";

    private static final String COPY_FRAGMENT_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "uniform sampler2D DiffuseSampler;\n"
            + "void main() {\n"
            + "    fragColor = texture(DiffuseSampler, texCoord);\n"
            + "}\n";

    private static final String POST_FRAGMENT_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "\n"
            + "uniform sampler2D DiffuseSampler;\n"
            + "uniform sampler2D BloomSampler;\n"
            + "uniform sampler2D GodraySampler;\n"
            + "uniform sampler2D CloudSampler;\n"
            + "uniform sampler2D DepthSampler;\n"
            + "uniform int UseDepthTexture;\n"
            + "uniform int DebugMode;\n"
            + "uniform vec4 ViewportInfo;\n"
            + "uniform vec4 SunInfo;\n"
            + "\n"
            + "uniform int EnableSharpening;\n"
            + "uniform float Sharpness;\n"
            + "uniform float EdgeThreshold;\n"
            + "\n"
            + "uniform int EnableBloom;\n"
            + "uniform float BloomIntensity;\n"
            + "\n"
            + "uniform int EnableGodrays;\n"
            + "uniform float GodrayIntensity;\n"
            + "\n"
            + "uniform int EnableLensFlare;\n"
            + "uniform float LensFlareIntensity;\n"
            + "uniform float LensFlareHalo;\n"
            + "uniform float LensFlareGhost;\n"
            + "uniform float LensFlareStreak;\n"
            + "\n"
            + "uniform int EnableClouds;\n"
            + "\n"
            + "uniform int EnableColorGrading;\n"
            + "uniform float Exposure;\n"
            + "uniform float Contrast;\n"
            + "uniform float Saturation;\n"
            + "uniform float Vibrance;\n"
            + "uniform float ColorTemperature;\n"
            + "\n"
            + "uniform int EnableTonemapping;\n"
            + "\n"
            + "// --- 1. Edge-Adaptive Contrast Sharpening (EACS) with Anti-Ringing ---\n"
            + "vec3 applyEACS(sampler2D tex, vec2 uv, vec2 px, float sharpness, float threshold) {\n"
            + "    vec3 c = texture(tex, uv).rgb;\n"
            + "    vec3 l = texture(tex, uv - vec2(px.x, 0.0)).rgb;\n"
            + "    vec3 r = texture(tex, uv + vec2(px.x, 0.0)).rgb;\n"
            + "    vec3 u = texture(tex, uv - vec2(0.0, px.y)).rgb;\n"
            + "    vec3 d = texture(tex, uv + vec2(0.0, px.y)).rgb;\n"
            + "\n"
            + "    float lumC = dot(c, vec3(0.299, 0.587, 0.114));\n"
            + "    float lumL = dot(l, vec3(0.299, 0.587, 0.114));\n"
            + "    float lumR = dot(r, vec3(0.299, 0.587, 0.114));\n"
            + "    float lumU = dot(u, vec3(0.299, 0.587, 0.114));\n"
            + "    float lumD = dot(d, vec3(0.299, 0.587, 0.114));\n"
            + "\n"
            + "    float minL = min(lumC, min(min(lumL, lumR), min(lumU, lumD)));\n"
            + "    float maxL = max(lumC, max(max(lumL, lumR), max(lumU, lumD)));\n"
            + "    float contrast = maxL - minL;\n"
            + "\n"
            + "    if (contrast > threshold) {\n"
            + "        vec3 laplacian = (l + r + u + d) * 0.25 - c;\n"
            + "        vec3 sharpened = c - laplacian * (sharpness * 1.35);\n"
            + "        vec3 minColor = min(c, min(min(l, r), min(u, d)));\n"
            + "        vec3 maxColor = max(c, max(max(l, r), max(u, d)));\n"
            + "        return clamp(sharpened, minColor * 0.90, maxColor * 1.10);\n"
            + "    }\n"
            + "    return c;\n"
            + "}\n"
            + "\n"
            + "// --- 2. Cinematic Lens Flare (Preserves Sun Disc, No Overexposure) ---\n"
            + "vec3 applyLensFlare(vec2 uv, vec2 sunUV, float sunOcclusion, float intensity, float haloStr, float ghostStr, float streakStr) {\n"
            + "    if (sunOcclusion <= 0.02 || intensity <= 0.01) return vec3(0.0);\n"
            + "    vec2 center = vec2(0.5);\n"
            + "    vec2 toCenter = center - sunUV;\n"
            + "    float distSun = length(uv - sunUV);\n"
            + "\n"
            + "    // Halo ring around the sun, with smooth hollow center to preserve the sun disc itself\n"
            + "    float sunCorona = smoothstep(0.015, 0.06, distSun) * exp(-distSun * 6.5) * haloStr * 0.55;\n"
            + "    vec3 flare = vec3(1.15, 1.05, 0.88) * sunCorona;\n"
            + "\n"
            + "    // Delicate anamorphic horizontal streak\n"
            + "    vec2 streakUV = uv - sunUV;\n"
            + "    float sharpStreak = exp(-abs(streakUV.y) * 85.0) * exp(-abs(streakUV.x) * 2.5);\n"
            + "    float softStreak = exp(-abs(streakUV.y) * 22.0) * exp(-abs(streakUV.x) * 1.2);\n"
            + "    flare += vec3(0.40, 0.75, 1.20) * (sharpStreak * 0.35 + softStreak * 0.12) * streakStr;\n"
            + "\n"
            + "    // Subtle starburst diffraction spikes\n"
            + "    float ang = atan(streakUV.y, streakUV.x);\n"
            + "    float starSpikes = pow(abs(cos(ang * 3.0)), 12.0) * exp(-distSun * 12.0) * smoothstep(0.01, 0.04, distSun);\n"
            + "    flare += vec3(1.05, 0.95, 0.75) * starSpikes * 0.16 * haloStr;\n"
            + "\n"
            + "    // Delicate chromatic ghost discs across the screen axis\n"
            + "    vec2 p1 = sunUV + toCenter * 0.45;\n"
            + "    flare += vec3(1.00, 0.70, 0.30) * exp(-dot(uv - p1, uv - p1) * 180.0) * 0.14 * ghostStr;\n"
            + "\n"
            + "    vec2 p2 = sunUV + toCenter * 0.75;\n"
            + "    flare += vec3(0.25, 0.75, 1.10) * exp(-dot(uv - p2, uv - p2) * 220.0) * 0.12 * ghostStr;\n"
            + "\n"
            + "    vec2 p3 = sunUV + toCenter * 1.20;\n"
            + "    flare += vec3(0.75, 0.40, 0.95) * exp(-dot(uv - p3, uv - p3) * 140.0) * 0.10 * ghostStr;\n"
            + "\n"
            + "    return flare * (sunOcclusion * intensity);\n"
            + "}\n"
            + "\n"
            + "// --- 3. Photographic Color Grading & White Balance ---\n"
            + "vec3 applyColorGrading(vec3 col, float expFactor, float contrast, float saturation, float vibrance, float temperature) {\n"
            + "    col *= expFactor;\n"
            + "    vec3 tempShift = vec3(1.0 + (temperature - 1.0) * 0.14, 1.0, 1.0 - (temperature - 1.0) * 0.14);\n"
            + "    col *= tempShift;\n"
            + "    col = max(vec3(0.0), (col - vec3(0.18)) * contrast + vec3(0.18));\n"
            + "    float lum = dot(col, vec3(0.2126, 0.7152, 0.0722));\n"
            + "    col = mix(vec3(lum), col, saturation);\n"
            + "    float maxC = max(col.r, max(col.g, col.b));\n"
            + "    float minC = min(col.r, min(col.g, col.b));\n"
            + "    float sat = maxC - minC;\n"
            + "    col = mix(vec3(lum), col, 1.0 + (1.0 - sat) * (vibrance - 1.0));\n"
            + "    return max(vec3(0.0), col);\n"
            + "}\n"
            + "\n"
            + "// --- 4. Normalized ACES Filmic Curve (preserves peak white 1.0) ---\n"
            + "vec3 ACESFilm(vec3 x) {\n"
            + "    float a = 2.51; float b = 0.03; float c = 2.43; float d = 0.59; float e = 0.14;\n"
            + "    vec3 mapped = (x * (a * x + b)) / (x * (c * x + d) + e);\n"
            + "    return clamp(mapped * 1.244, 0.0, 1.0);\n"
            + "}\n"
            + "\n"
            + "void main() {\n"
            + "    vec2 px = ViewportInfo.xy;\n"
            + "    vec3 origColor = texture(DiffuseSampler, texCoord).rgb;\n"
            + "\n"
            + "    // Debug Mode 1: Passthrough original scene\n"
            + "    if (DebugMode == 1) {\n"
            + "        fragColor = vec4(origColor, 1.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // 1. Base color + EACS sharpening\n"
            + "    vec3 baseColor = origColor;\n"
            + "    if (EnableSharpening == 1) {\n"
            + "        baseColor = applyEACS(DiffuseSampler, texCoord, px, Sharpness, EdgeThreshold);\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 7: Sharpening edge difference map\n"
            + "    if (DebugMode == 7) {\n"
            + "        vec3 edgeMap = abs(baseColor - origColor) * 12.0;\n"
            + "        fragColor = vec4(edgeMap, 1.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // 2. Volumetric Clouds Composite (blended before lighting)\n"
            + "    if (EnableClouds == 1) {\n"
            + "        vec4 cloud = texture(CloudSampler, texCoord);\n"
            + "        if (cloud.a > 0.001) {\n"
            + "            baseColor = mix(baseColor, cloud.rgb, cloud.a);\n"
            + "        }\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 9: Volumetric Clouds only\n"
            + "    if (DebugMode == 9) {\n"
            + "        vec4 cloud = texture(CloudSampler, texCoord);\n"
            + "        fragColor = vec4(cloud.rgb, 1.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // 3. Multi-Scale Bloom\n"
            + "    vec3 bloomColor = vec3(0.0);\n"
            + "    if (EnableBloom == 1) {\n"
            + "        bloomColor = texture(BloomSampler, texCoord).rgb * BloomIntensity;\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 2 or 3: Bloom isolated\n"
            + "    if (DebugMode == 2 || DebugMode == 3) {\n"
            + "        fragColor = vec4(bloomColor * 1.5, 1.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // 4. Downsampled Crepuscular Godrays\n"
            + "    vec3 godrays = vec3(0.0);\n"
            + "    if (EnableGodrays == 1) {\n"
            + "        godrays = texture(GodraySampler, texCoord).rgb * GodrayIntensity;\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 4: Godrays only on black\n"
            + "    if (DebugMode == 4) {\n"
            + "        fragColor = vec4(godrays * 2.0, 1.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // 5. Cinematic Lens Flare\n"
            + "    float sunOcclusion = SunInfo.z;\n"
            + "    vec3 lensFlare = vec3(0.0);\n"
            + "    if (EnableLensFlare == 1 && sunOcclusion > 0.01) {\n"
            + "        lensFlare = applyLensFlare(texCoord, SunInfo.xy, sunOcclusion, LensFlareIntensity, LensFlareHalo, LensFlareGhost, LensFlareStreak);\n"
            + "    }\n"
            + "\n"
            + "    // Composite lighting into base color with soft filmic compression (no white clipping)\n"
            + "    vec3 lightAdd = bloomColor + godrays + lensFlare;\n"
            + "    vec3 result = baseColor + lightAdd * max(vec3(0.0), vec3(1.0) - baseColor * 0.65);\n"
            + "\n"
            + "    // 6. Color Grading & ACES Tonemapping\n"
            + "    if (EnableColorGrading == 1) {\n"
            + "        result = applyColorGrading(result, Exposure, Contrast, Saturation, Vibrance, ColorTemperature);\n"
            + "    }\n"
            + "\n"
            + "    if (EnableTonemapping == 1) {\n"
            + "        result = ACESFilm(result);\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 8: Color grading only\n"
            + "    if (DebugMode == 8) {\n"
            + "        vec3 cgOnly = origColor;\n"
            + "        if (EnableColorGrading == 1) cgOnly = applyColorGrading(cgOnly, Exposure, Contrast, Saturation, Vibrance, ColorTemperature);\n"
            + "        if (EnableTonemapping == 1) cgOnly = ACESFilm(cgOnly);\n"
            + "        fragColor = vec4(clamp(cgOnly, 0.0, 1.0), 1.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 5: Sun Position & Marker Reticle\n"
            + "    if (DebugMode == 5) {\n"
            + "        vec2 aspect = vec2(ViewportInfo.z / ViewportInfo.w, 1.0);\n"
            + "        vec2 dSun = (texCoord - SunInfo.xy) * aspect;\n"
            + "        float distSun = length(dSun);\n"
            + "        float ring = smoothstep(0.003, 0.0, abs(distSun - 0.025));\n"
            + "        float crosshair = smoothstep(0.002, 0.0, min(abs(dSun.x), abs(dSun.y))) * step(distSun, 0.045);\n"
            + "        vec3 markerCol = SunInfo.z > 0.05 ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);\n"
            + "        result = mix(result, markerCol, clamp(ring + crosshair, 0.0, 1.0));\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 6: Sun Occlusion Visualization\n"
            + "    if (DebugMode == 6) {\n"
            + "        vec3 statusTint = mix(vec3(1.0, 0.0, 0.0), vec3(0.0, 1.0, 0.0), SunInfo.z);\n"
            + "        if (texCoord.y > 0.95) {\n"
            + "            result = statusTint;\n"
            + "        } else {\n"
            + "            result = mix(result, statusTint, 0.20);\n"
            + "        }\n"
            + "    }\n"
            + "\n"
            + "    // Debug Mode 10: Split Screen (Left = Original Vanilla, Right = RumbleGraphics)\n"
            + "    if (DebugMode == 10) {\n"
            + "        if (abs(texCoord.x - 0.5) < 0.0015) {\n"
            + "            fragColor = vec4(1.0, 1.0, 0.0, 1.0); // Yellow divider line\n"
            + "            return;\n"
            + "        } else if (texCoord.x < 0.5) {\n"
            + "            fragColor = vec4(origColor, 1.0);\n"
            + "            return;\n"
            + "        }\n"
            + "    }\n"
            + "\n"
            + "    fragColor = vec4(clamp(result, 0.0, 1.0), 1.0);\n"
            + "}\n";

    private static void initQuad() {
        if (quadVao != 0) return;

        float[] quadVertices = {
            -1.0f, -1.0f,  0.0f, 0.0f,
             1.0f, -1.0f,  1.0f, 0.0f,
             1.0f,  1.0f,  1.0f, 1.0f,
            -1.0f, -1.0f,  0.0f, 0.0f,
             1.0f,  1.0f,  1.0f, 1.0f,
            -1.0f,  1.0f,  0.0f, 1.0f
        };

        FloatBuffer buffer = MemoryUtil.memAllocFloat(quadVertices.length);
        buffer.put(quadVertices).flip();

        quadVao = GL30.glGenVertexArrays();
        quadVbo = GL15.glGenBuffers();

        GL30.glBindVertexArray(quadVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, quadVbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);

        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 4 * Float.BYTES, 0);
        GL20.glEnableVertexAttribArray(0);

        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 4 * Float.BYTES, 2 * Float.BYTES);
        GL20.glEnableVertexAttribArray(1);

        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        GL30.glBindVertexArray(0);

        MemoryUtil.memFree(buffer);
    }

    private static void init() {
        if (initialized || failed) return;

        initQuad();

        postProcessProgramId = compileProgram(VERTEX_SRC, POST_FRAGMENT_SRC);
        copyProgramId = compileProgram(VERTEX_SRC, COPY_FRAGMENT_SRC);

        if (postProcessProgramId == 0 || copyProgramId == 0) {
            failed = true;
            RumbleGraphics.LOGGER.error("[RumbleGraphics] PostProcessPipeline shaders failed to compile!");
            return;
        }

        // Query Post-Process Uniforms
        locViewportInfo = GL20.glGetUniformLocation(postProcessProgramId, "ViewportInfo");
        locSunInfo = GL20.glGetUniformLocation(postProcessProgramId, "SunInfo");
        locDiffuseSampler = GL20.glGetUniformLocation(postProcessProgramId, "DiffuseSampler");
        locBloomSampler = GL20.glGetUniformLocation(postProcessProgramId, "BloomSampler");
        locGodraySampler = GL20.glGetUniformLocation(postProcessProgramId, "GodraySampler");
        locCloudSampler = GL20.glGetUniformLocation(postProcessProgramId, "CloudSampler");
        locDepthSampler = GL20.glGetUniformLocation(postProcessProgramId, "DepthSampler");
        locUseDepthTexture = GL20.glGetUniformLocation(postProcessProgramId, "UseDepthTexture");
        locDebugMode = GL20.glGetUniformLocation(postProcessProgramId, "DebugMode");

        locEnableSharpening = GL20.glGetUniformLocation(postProcessProgramId, "EnableSharpening");
        locSharpness = GL20.glGetUniformLocation(postProcessProgramId, "Sharpness");
        locEdgeThreshold = GL20.glGetUniformLocation(postProcessProgramId, "EdgeThreshold");

        locEnableBloom = GL20.glGetUniformLocation(postProcessProgramId, "EnableBloom");
        locBloomIntensity = GL20.glGetUniformLocation(postProcessProgramId, "BloomIntensity");

        locEnableGodrays = GL20.glGetUniformLocation(postProcessProgramId, "EnableGodrays");
        locGodrayIntensity = GL20.glGetUniformLocation(postProcessProgramId, "GodrayIntensity");

        locEnableLensFlare = GL20.glGetUniformLocation(postProcessProgramId, "EnableLensFlare");
        locLensFlareIntensity = GL20.glGetUniformLocation(postProcessProgramId, "LensFlareIntensity");
        locLensFlareHalo = GL20.glGetUniformLocation(postProcessProgramId, "LensFlareHalo");
        locLensFlareGhost = GL20.glGetUniformLocation(postProcessProgramId, "LensFlareGhost");
        locLensFlareStreak = GL20.glGetUniformLocation(postProcessProgramId, "LensFlareStreak");

        locEnableClouds = GL20.glGetUniformLocation(postProcessProgramId, "EnableClouds");

        locEnableColorGrading = GL20.glGetUniformLocation(postProcessProgramId, "EnableColorGrading");
        locExposure = GL20.glGetUniformLocation(postProcessProgramId, "Exposure");
        locContrast = GL20.glGetUniformLocation(postProcessProgramId, "Contrast");
        locSaturation = GL20.glGetUniformLocation(postProcessProgramId, "Saturation");
        locVibrance = GL20.glGetUniformLocation(postProcessProgramId, "Vibrance");
        locColorTemperature = GL20.glGetUniformLocation(postProcessProgramId, "ColorTemperature");

        locEnableTonemapping = GL20.glGetUniformLocation(postProcessProgramId, "EnableTonemapping");

        locCopyDiffuseSampler = GL20.glGetUniformLocation(copyProgramId, "DiffuseSampler");

        bloomPyramid.init();
        godrayPass.init();
        volumetricClouds.init();

        initialized = true;
        RumbleGraphics.LOGGER.info("[RumbleGraphics] PostProcessPipeline initialized successfully for MobileGlues/Turnip.");
    }

    public static void render(RenderTarget mainTarget, float tickDelta) {
        long startTime = System.nanoTime();
        RumbleConfig config = RumbleConfig.get();
        if (!config.masterEnabled) {
            pipelineActiveLastFrame = false;
            return;
        }

        int debugMode = config.debugMode;
        boolean needSharpening = config.enableSnapdragonGSR && (config.renderScale >= 100);
        boolean needBloom = config.enableBloom;
        boolean needGodrays = config.enableGodrays;
        boolean needLensFlare = config.enableLensFlare;
        boolean needClouds = config.enableClouds;
        boolean needVibrance = config.enableVibrance;
        boolean needTonemapping = config.enableTonemapping;
        boolean needColorGrading = needVibrance || (config.colorExposure != 100) || (config.colorContrast != 100)
                || (config.colorSaturation != 100) || (config.colorTemperature != 100);

        if (debugMode == 0 && !needSharpening && !needBloom && !needGodrays && !needLensFlare && !needClouds && !needColorGrading && !needTonemapping) {
            pipelineActiveLastFrame = false;
            return;
        }

        if (mainTarget == null || mainTarget.getColorTextureId() <= 0) {
            pipelineActiveLastFrame = false;
            return;
        }

        if (!initialized) {
            init();
            if (failed) return;
        }

        int width = mainTarget.width;
        int height = mainTarget.height;
        if (width <= 0 || height <= 0) return;

        lastWidth = width;
        lastHeight = height;
        frameCount++;

        // Capture complete OpenGL state before any modification
        glState.capture();

        try {
            // Manage secondary offscreen ping-pong framebuffer
            if (secondaryTarget == null || secondaryTarget.width != width || secondaryTarget.height != height) {
                if (secondaryTarget != null) {
                    secondaryTarget.destroyBuffers();
                }
                secondaryTarget = new TextureTarget(width, height, false, Minecraft.ON_OSX);
            }

            // Update Sun Projection and Voxel Occlusion
            Minecraft mc = Minecraft.getInstance();
            sunTracker.update(mc, tickDelta, width, height);
            sunOcclusion.update(mc, sunTracker, needGodrays || needLensFlare || debugMode == 4 || debugMode == 5 || debugMode == 6);

            float sunX = sunTracker.getScreenX();
            float sunY = sunTracker.getScreenY();
            float sunVis = sunTracker.getSunInFront() * sunOcclusion.getSmoothOcclusion();
            float horizonFade = sunTracker.getHorizonFade();

            int depthTexId = mainTarget.getDepthTextureId();
            boolean canSampleDepth = mainTarget.useDepth && depthTexId > 0 && GL11.glIsTexture(depthTexId);

            // ========================================================
            // STEP A: Multi-Scale Kawase Bloom Pyramid Extraction
            // ========================================================
            int bloomTexId = 0;
            if (needBloom || debugMode == 2 || debugMode == 3) {
                float bloomThresh = (config.bloomThreshold / 100.0f);
                bloomTexId = bloomPyramid.process(mainTarget.getColorTextureId(), width, height, bloomThresh, quadVao, config.bloomQuality);

                if (debugMode == 2) {
                    bloomTexId = bloomPyramid.getExtractionTextureId();
                }
            }

            // ========================================================
            // STEP B: Decoupled Low-Resolution Godray Pass (1/4 or 1/2 res)
            // ========================================================
            int godrayTexId = 0;
            if (needGodrays || debugMode == 4) {
                float godrayStr = (config.godrayIntensity / 100.0f);
                godrayTexId = godrayPass.render(mainTarget.getColorTextureId(), depthTexId, canSampleDepth,
                        width, height, sunTracker, sunVis, godrayStr, config.godrayQuality, config.godrayDownscale, quadVao);
            }

            // ========================================================
            // STEP C: Lightweight Screen-Space Volumetric Clouds (1/4 res)
            // ========================================================
            int cloudTexId = 0;
            if (needClouds || debugMode == 9) {
                float cloudDensity = (config.cloudDensity / 100.0f);
                float cloudSpeed = (config.cloudSpeed / 100.0f);
                cloudTexId = volumetricClouds.render(depthTexId, canSampleDepth, width, height,
                        sunTracker, sunVis, cloudDensity, config.cloudQuality, cloudSpeed, quadVao);
            }

            // ========================================================
            // STEP D: Main Post-Processing Composite into secondaryTarget
            // ========================================================
            glState.prepareFullscreenPass(width, height);
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, secondaryTarget.frameBufferId);

            GL20.glUseProgram(postProcessProgramId);

            float sharpness = 1.0f + (config.gsrSharpness / 100.0f) * 2.0f;
            float threshold = (120.0f - config.gsrSensitivity) / 255.0f * 0.12f;
            float bloomStr = (config.bloomIntensity / 100.0f);
            float godrayStr = (config.godrayIntensity / 100.0f);
            float flareStr = (config.lensFlareIntensity / 100.0f);
            float haloStr = (config.lensFlareHaloIntensity / 100.0f);
            float ghostStr = (config.lensFlareGhostIntensity / 100.0f);
            float streakStr = (config.lensFlareStreakIntensity / 100.0f);

            float expVal = (config.colorExposure / 100.0f);
            float contVal = (config.colorContrast / 100.0f);
            float satVal = (config.colorSaturation / 100.0f);
            float vibVal = needVibrance ? 1.30f : 1.0f;
            float tempVal = (config.colorTemperature / 100.0f);

            if (locViewportInfo != -1) GL20.glUniform4f(locViewportInfo, 1.0f / width, 1.0f / height, (float) width, (float) height);
            if (locSunInfo != -1) GL20.glUniform4f(locSunInfo, sunX, sunY, sunVis, horizonFade);
            if (locDebugMode != -1) GL20.glUniform1i(locDebugMode, debugMode);

            if (locEnableSharpening != -1) GL20.glUniform1i(locEnableSharpening, needSharpening ? 1 : 0);
            if (locSharpness != -1) GL20.glUniform1f(locSharpness, sharpness);
            if (locEdgeThreshold != -1) GL20.glUniform1f(locEdgeThreshold, threshold);

            if (locEnableBloom != -1) GL20.glUniform1i(locEnableBloom, (needBloom && bloomTexId > 0) ? 1 : 0);
            if (locBloomIntensity != -1) GL20.glUniform1f(locBloomIntensity, bloomStr);

            if (locEnableGodrays != -1) GL20.glUniform1i(locEnableGodrays, (needGodrays && godrayTexId > 0) ? 1 : 0);
            if (locGodrayIntensity != -1) GL20.glUniform1f(locGodrayIntensity, godrayStr);

            if (locEnableLensFlare != -1) GL20.glUniform1i(locEnableLensFlare, needLensFlare ? 1 : 0);
            if (locLensFlareIntensity != -1) GL20.glUniform1f(locLensFlareIntensity, flareStr);
            if (locLensFlareHalo != -1) GL20.glUniform1f(locLensFlareHalo, haloStr);
            if (locLensFlareGhost != -1) GL20.glUniform1f(locLensFlareGhost, ghostStr);
            if (locLensFlareStreak != -1) GL20.glUniform1f(locLensFlareStreak, streakStr);

            if (locEnableClouds != -1) GL20.glUniform1i(locEnableClouds, (needClouds && cloudTexId > 0) ? 1 : 0);

            if (locEnableColorGrading != -1) GL20.glUniform1i(locEnableColorGrading, needColorGrading ? 1 : 0);
            if (locExposure != -1) GL20.glUniform1f(locExposure, expVal);
            if (locContrast != -1) GL20.glUniform1f(locContrast, contVal);
            if (locSaturation != -1) GL20.glUniform1f(locSaturation, satVal);
            if (locVibrance != -1) GL20.glUniform1f(locVibrance, vibVal);
            if (locColorTemperature != -1) GL20.glUniform1f(locColorTemperature, tempVal);

            if (locEnableTonemapping != -1) GL20.glUniform1i(locEnableTonemapping, needTonemapping ? 1 : 0);

            // Bind Diffuse Source to TEXTURE0
            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, mainTarget.getColorTextureId());
            if (locDiffuseSampler != -1) GL20.glUniform1i(locDiffuseSampler, 0);

            // Bind Multi-Scale Bloom Texture to TEXTURE1
            if (bloomTexId > 0) {
                GL13.glActiveTexture(GL13.GL_TEXTURE1);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, bloomTexId);
                if (locBloomSampler != -1) GL20.glUniform1i(locBloomSampler, 1);
            }

            // Bind Low-Resolution Godrays Texture to TEXTURE2
            if (godrayTexId > 0) {
                GL13.glActiveTexture(GL13.GL_TEXTURE2);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, godrayTexId);
                if (locGodraySampler != -1) GL20.glUniform1i(locGodraySampler, 2);
            }

            // Bind Volumetric Clouds Texture to TEXTURE3
            if (cloudTexId > 0) {
                GL13.glActiveTexture(GL13.GL_TEXTURE3);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, cloudTexId);
                if (locCloudSampler != -1) GL20.glUniform1i(locCloudSampler, 3);
            }

            // Bind Depth Texture to TEXTURE4 if needed
            if (canSampleDepth) {
                GL13.glActiveTexture(GL13.GL_TEXTURE4);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexId);
                if (locDepthSampler != -1) GL20.glUniform1i(locDepthSampler, 4);
                if (locUseDepthTexture != -1) GL20.glUniform1i(locUseDepthTexture, 1);
            } else {
                if (locUseDepthTexture != -1) GL20.glUniform1i(locUseDepthTexture, 0);
            }

            GL30.glBindVertexArray(quadVao);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
            GL30.glBindVertexArray(0);
            GL20.glUseProgram(0);

            // ========================================================
            // STEP E: Copy processed frame back to mainTarget
            // ========================================================
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, mainTarget.frameBufferId);
            glState.prepareFullscreenPass(width, height);

            GL20.glUseProgram(copyProgramId);
            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, secondaryTarget.getColorTextureId());
            if (locCopyDiffuseSampler != -1) GL20.glUniform1i(locCopyDiffuseSampler, 0);

            GL30.glBindVertexArray(quadVao);
            GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
            GL30.glBindVertexArray(0);
            GL20.glUseProgram(0);

            pipelineActiveLastFrame = true;
        } catch (Throwable t) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] PostProcessPipeline execution error: ", t);
            pipelineActiveLastFrame = false;
        } finally {
            glState.restore();
            lastExecutionNanos = System.nanoTime() - startTime;
        }
    }

    public static void destroy() {
        bloomPyramid.destroy();
        godrayPass.destroy();
        volumetricClouds.destroy();

        if (secondaryTarget != null) {
            secondaryTarget.destroyBuffers();
            secondaryTarget = null;
        }

        if (postProcessProgramId != 0) {
            GL20.glDeleteProgram(postProcessProgramId);
            postProcessProgramId = 0;
        }
        if (copyProgramId != 0) {
            GL20.glDeleteProgram(copyProgramId);
            copyProgramId = 0;
        }

        if (quadVao != 0) {
            GL30.glDeleteVertexArrays(quadVao);
            quadVao = 0;
        }
        if (quadVbo != 0) {
            GL15.glDeleteBuffers(quadVbo);
            quadVbo = 0;
        }

        sunOcclusion.reset();

        initialized = false;
        failed = false;
        pipelineActiveLastFrame = false;
        RumbleGraphics.LOGGER.info("[RumbleGraphics] PostProcessPipeline GPU resources freed cleanly.");
    }

    private static int compileProgram(String vertSrc, String fragSrc) {
        int vert = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vert, vertSrc);
        GL20.glCompileShader(vert);
        if (GL20.glGetShaderi(vert, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Vertex Shader Compile Failed: {}", GL20.glGetShaderInfoLog(vert));
            GL20.glDeleteShader(vert);
            return 0;
        }

        int frag = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(frag, fragSrc);
        GL20.glCompileShader(frag);
        if (GL20.glGetShaderi(frag, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Fragment Shader Compile Failed: {}", GL20.glGetShaderInfoLog(frag));
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            return 0;
        }

        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vert);
        GL20.glAttachShader(prog, frag);
        GL20.glLinkProgram(prog);

        GL20.glDeleteShader(vert);
        GL20.glDeleteShader(frag);

        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Program Linking Failed: {}", GL20.glGetProgramInfoLog(prog));
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }

    // Diagnostic Getters
    public static long getFrameCount() {
        return frameCount;
    }

    public static int getLastWidth() {
        return lastWidth;
    }

    public static int getLastHeight() {
        return lastHeight;
    }

    public static boolean isPipelineActive() {
        return pipelineActiveLastFrame;
    }

    public static long getLastExecutionNanos() {
        return lastExecutionNanos;
    }

    public static boolean areShadersCompiled() {
        return postProcessProgramId != 0 && copyProgramId != 0;
    }

    public static SunTracker getSunTracker() {
        return sunTracker;
    }

    public static SunOcclusion getSunOcclusion() {
        return sunOcclusion;
    }

    public static BloomPyramid getBloomPyramid() {
        return bloomPyramid;
    }

    public static GodrayPass getGodrayPass() {
        return godrayPass;
    }

    public static VolumetricClouds getVolumetricClouds() {
        return volumetricClouds;
    }
}
