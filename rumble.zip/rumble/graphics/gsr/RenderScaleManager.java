package com.rumble.graphics.gsr;

import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.rumble.graphics.RumbleGraphics;
import com.rumble.graphics.config.RumbleConfig;
import com.rumble.graphics.gl.GLStateManagerHelper;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryUtil;

import java.nio.FloatBuffer;

/**
 * True Internal Render Resolution Scaling & Spatial Reconstruction Pipeline (EASU + EACS).
 * Provides genuine 3D level downsampling (50%, 67%, 75%, 90%, 100%) to drastically reduce
 * Adreno 740 fragment shading load, while keeping the 2D Minecraft GUI/HUD at 100% native resolution.
 */
public class RenderScaleManager {

    private static final GLStateManagerHelper glState = new GLStateManagerHelper();

    private static TextureTarget scaledTarget = null;
    private static volatile boolean scaleActive = false;

    private static int easuProgramId = 0;
    private static int quadVao = 0;
    private static int quadVbo = 0;

    private static int locSourceTex = -1;
    private static int locSourceTexelSize = -1;
    private static int locDisplaySize = -1;
    private static int locSharpness = -1;

    private static boolean initialized = false;
    private static boolean failed = false;

    // Runtime metrics
    private static int currentScaledWidth = 0;
    private static int currentScaledHeight = 0;
    private static int currentNativeWidth = 0;
    private static int currentNativeHeight = 0;
    private static int activeScalePercent = 100;

    private static final String VERTEX_SRC = "#version 330 core\n"
            + "layout(location = 0) in vec2 inPosition;\n"
            + "layout(location = 1) in vec2 inTexCoord;\n"
            + "out vec2 texCoord;\n"
            + "void main() {\n"
            + "    texCoord = inTexCoord;\n"
            + "    gl_Position = vec4(inPosition, 0.0, 1.0);\n"
            + "}\n";

    /**
     * Edge-Adaptive Spatial Upscaling (EASU) + Edge-Adaptive Contrast Sharpening (EACS).
     * Reconstructs sharp edges from lower-resolution 3D render target into native display target.
     */
    private static final String EASU_FRAGMENT_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "\n"
            + "uniform sampler2D SourceTex;\n"
            + "uniform vec2 SourceTexelSize;\n" // 1.0 / scaledW, 1.0 / scaledH
            + "uniform vec2 DisplaySize;\n"       // nativeW, nativeH
            + "uniform float Sharpness;\n"        // 0.0 - 2.0
            + "\n"
            + "float rgbToLum(vec3 c) {\n"
            + "    return dot(c, vec3(0.299, 0.587, 0.114));\n"
            + "}\n"
            + "\n"
            + "void main() {\n"
            + "    vec2 uv = texCoord;\n"
            + "    vec2 px = SourceTexelSize;\n"
            + "\n"
            + "    // Sample central 3x3 tap neighborhood\n"
            + "    vec3 c  = texture(SourceTex, uv).rgb;\n"
            + "    vec3 l  = texture(SourceTex, uv - vec2(px.x, 0.0)).rgb;\n"
            + "    vec3 r  = texture(SourceTex, uv + vec2(px.x, 0.0)).rgb;\n"
            + "    vec3 u  = texture(SourceTex, uv - vec2(0.0, px.y)).rgb;\n"
            + "    vec3 d  = texture(SourceTex, uv + vec2(0.0, px.y)).rgb;\n"
            + "    vec3 ul = texture(SourceTex, uv + vec2(-px.x, -px.y)).rgb;\n"
            + "    vec3 ur = texture(SourceTex, uv + vec2( px.x, -px.y)).rgb;\n"
            + "    vec3 dl = texture(SourceTex, uv + vec2(-px.x,  px.y)).rgb;\n"
            + "    vec3 dr = texture(SourceTex, uv + vec2( px.x,  px.y)).rgb;\n"
            + "\n"
            + "    float lumC  = rgbToLum(c);\n"
            + "    float lumL  = rgbToLum(l);\n"
            + "    float lumR  = rgbToLum(r);\n"
            + "    float lumU  = rgbToLum(u);\n"
            + "    float lumD  = rgbToLum(d);\n"
            + "    float lumUL = rgbToLum(ul);\n"
            + "    float lumUR = rgbToLum(ur);\n"
            + "    float lumDL = rgbToLum(dl);\n"
            + "    float lumDR = rgbToLum(dr);\n"
            + "\n"
            + "    // Detect local gradient directions\n"
            + "    float gradH = abs(lumL - lumR);\n"
            + "    float gradV = abs(lumU - lumD);\n"
            + "    float gradD1 = abs(lumUL - lumDR);\n"
            + "    float gradD2 = abs(lumUR - lumDL);\n"
            + "\n"
            + "    // Directional reconstruction weights\n"
            + "    float wH = 1.0 / (1.0 + gradH * 4.0);\n"
            + "    float wV = 1.0 / (1.0 + gradV * 4.0);\n"
            + "    float wD1 = 0.5 / (1.0 + gradD1 * 4.0);\n"
            + "    float wD2 = 0.5 / (1.0 + gradD2 * 4.0);\n"
            + "\n"
            + "    vec3 edgeSum = c * 2.0 + (l + r) * wH + (u + d) * wV + (ul + dr) * wD1 + (ur + dl) * wD2;\n"
            + "    float weightSum = 2.0 + 2.0 * wH + 2.0 * wV + 2.0 * wD1 + 2.0 * wD2;\n"
            + "    vec3 reconstructed = edgeSum / weightSum;\n"
            + "\n"
            + "    // Local bounding box for anti-ringing\n"
            + "    vec3 minCol = min(c, min(min(l, r), min(u, d)));\n"
            + "    vec3 maxCol = max(c, max(max(l, r), max(u, d)));\n"
            + "    reconstructed = clamp(reconstructed, minCol, maxCol);\n"
            + "\n"
            + "    // EACS Sharpening pass\n"
            + "    if (Sharpness > 0.05) {\n"
            + "        vec3 laplacian = (l + r + u + d) * 0.25 - c;\n"
            + "        vec3 sharp = reconstructed - laplacian * Sharpness;\n"
            + "        reconstructed = clamp(sharp, minCol * 0.90, maxCol * 1.10);\n"
            + "    }\n"
            + "\n"
            + "    fragColor = vec4(clamp(reconstructed, 0.0, 1.0), 1.0);\n"
            + "}\n";

    private static void init() {
        if (initialized || failed) return;

        float[] quadVertices = {
            -1.0f, -1.0f,  0.0f, 0.0f,
             1.0f, -1.0f,  1.0f, 0.0f,
             1.0f,  1.0f,  1.0f, 1.0f,
            -1.0f, -1.0f,  0.0f, 0.0f,
             1.0f,  1.0f,  1.0f, 1.0f,
            -1.0f,  1.0f,  0.0f, 1.0f
        };

        FloatBuffer buffer = MemoryUtil.memAllocFloat(quadVertices.length);
        buffer.put(quadVertices).flip();

        quadVao = GL30.glGenVertexArrays();
        quadVbo = GL15.glGenBuffers();

        GL30.glBindVertexArray(quadVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, quadVbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, buffer, GL15.GL_STATIC_DRAW);

        GL20.glVertexAttribPointer(0, 2, GL11.GL_FLOAT, false, 4 * Float.BYTES, 0);
        GL20.glEnableVertexAttribArray(0);

        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 4 * Float.BYTES, 2 * Float.BYTES);
        GL20.glEnableVertexAttribArray(1);

        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
        GL30.glBindVertexArray(0);

        MemoryUtil.memFree(buffer);

        easuProgramId = compileProgram(VERTEX_SRC, EASU_FRAGMENT_SRC);
        if (easuProgramId == 0) {
            failed = true;
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Failed to compile EASU upscaler shader!");
            return;
        }

        locSourceTex = GL20.glGetUniformLocation(easuProgramId, "SourceTex");
        locSourceTexelSize = GL20.glGetUniformLocation(easuProgramId, "SourceTexelSize");
        locDisplaySize = GL20.glGetUniformLocation(easuProgramId, "DisplaySize");
        locSharpness = GL20.glGetUniformLocation(easuProgramId, "Sharpness");

        initialized = true;
        RumbleGraphics.LOGGER.info("[RumbleGraphics] RenderScaleManager initialized (EASU + EACS ready).");
    }

    public static boolean isScaleActive() {
        return scaleActive;
    }

    public static RenderTarget getScaledTarget() {
        return scaledTarget;
    }

    public static int getActiveScalePercent() {
        return activeScalePercent;
    }

    public static int getCurrentScaledWidth() {
        return currentScaledWidth;
    }

    public static int getCurrentScaledHeight() {
        return currentScaledHeight;
    }

    /**
     * Called at HEAD of GameRenderer.renderLevel.
     * Intercepts 3D level rendering to render into a reduced-resolution target if renderScale < 100%.
     */
    public static void beginLevelRender(Minecraft mc) {
        RumbleConfig config = RumbleConfig.get();
        if (!config.masterEnabled || config.renderScale >= 100) {
            scaleActive = false;
            activeScalePercent = 100;
            return;
        }

        if (!initialized) {
            init();
            if (failed) {
                scaleActive = false;
                return;
            }
        }

        int nativeW = mc.getWindow().getWidth();
        int nativeH = mc.getWindow().getHeight();
        if (nativeW <= 0 || nativeH <= 0) {
            scaleActive = false;
            return;
        }

        currentNativeWidth = nativeW;
        currentNativeHeight = nativeH;
        activeScalePercent = config.renderScale;

        float scaleFactor = config.renderScale / 100.0f;
        int scaledW = Math.max(16, Math.round(nativeW * scaleFactor));
        int scaledH = Math.max(16, Math.round(nativeH * scaleFactor));

        // Manage scaled target lifecycle
        if (scaledTarget == null || scaledTarget.width != scaledW || scaledTarget.height != scaledH) {
            if (scaledTarget != null) {
                scaledTarget.destroyBuffers();
            }
            scaledTarget = new TextureTarget(scaledW, scaledH, true, Minecraft.ON_OSX);
            scaledTarget.setFilterMode(GL11.GL_LINEAR);
        }

        currentScaledWidth = scaledW;
        currentScaledHeight = scaledH;

        // Activate scaled redirection
        scaleActive = true;
        scaledTarget.clear(Minecraft.ON_OSX);
        scaledTarget.bindWrite(true);
        GlStateManager._viewport(0, 0, scaledW, scaledH);
    }

    /**
     * Called after doEntityOutline in GameRenderer.render.
     * Completes post-processing on the scaled scene and performs EASU edge reconstruction upscaling
     * directly into Minecraft's native mainRenderTarget before GUI rendering begins.
     */
    public static void endLevelRender(Minecraft mc, float tickDelta) {
        if (!scaleActive || scaledTarget == null) {
            scaleActive = false;
            // Native 100% path: run post-processing directly on mainRenderTarget
            if (mc.level != null && mc.getMainRenderTarget() != null) {
                SnapdragonGSR.process(mc.getMainRenderTarget(), tickDelta);
            }
            return;
        }

        RumbleConfig config = RumbleConfig.get();

        try {
            // Step 1: Run complete Post-Processing (Bloom, Godrays, Flare, Clouds, Tonemapping)
            // at reduced resolution (saves massive GPU fillrate & bandwidth on Adreno 740!)
            PostProcessPipeline.render(scaledTarget, tickDelta);

            // Step 2: EASU Edge-Adaptive Upscaling into native mainRenderTarget
            RenderTarget nativeTarget = mc.getMainRenderTarget();
            if (nativeTarget != null && nativeTarget.frameBufferId > 0) {
                glState.capture();

                glState.prepareFullscreenPass(currentNativeWidth, currentNativeHeight);
                GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, nativeTarget.frameBufferId);

                GL20.glUseProgram(easuProgramId);

                float sharpness = config.enableSnapdragonGSR ? (config.gsrSharpness / 100.0f) * 1.5f : 0.0f;

                if (locSourceTexelSize != -1) {
                    GL20.glUniform2f(locSourceTexelSize, 1.0f / currentScaledWidth, 1.0f / currentScaledHeight);
                }
                if (locDisplaySize != -1) {
                    GL20.glUniform2f(locDisplaySize, (float) currentNativeWidth, (float) currentNativeHeight);
                }
                if (locSharpness != -1) {
                    GL20.glUniform1f(locSharpness, sharpness);
                }

                GL13.glActiveTexture(GL13.GL_TEXTURE0);
                GL11.glBindTexture(GL11.GL_TEXTURE_2D, scaledTarget.getColorTextureId());
                if (locSourceTex != -1) GL20.glUniform1i(locSourceTex, 0);

                GL30.glBindVertexArray(quadVao);
                GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
                GL30.glBindVertexArray(0);

                GL20.glUseProgram(0);

                glState.restore();
            }
        } catch (Throwable t) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Error during EASU upscaling pass: ", t);
        } finally {
            scaleActive = false;
            // Restore native write target and viewport for GUI
            if (mc.getMainRenderTarget() != null) {
                mc.getMainRenderTarget().bindWrite(true);
            }
            GlStateManager._viewport(0, 0, mc.getWindow().getWidth(), mc.getWindow().getHeight());
        }
    }

    public static void destroy() {
        if (scaledTarget != null) {
            scaledTarget.destroyBuffers();
            scaledTarget = null;
        }
        if (easuProgramId != 0) {
            GL20.glDeleteProgram(easuProgramId);
            easuProgramId = 0;
        }
        if (quadVao != 0) {
            GL30.glDeleteVertexArrays(quadVao);
            quadVao = 0;
        }
        if (quadVbo != 0) {
            GL15.glDeleteBuffers(quadVbo);
            quadVbo = 0;
        }
        initialized = false;
        failed = false;
        scaleActive = false;
    }

    private static int compileProgram(String vertSrc, String fragSrc) {
        int vert = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vert, vertSrc);
        GL20.glCompileShader(vert);
        if (GL20.glGetShaderi(vert, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] EASU Vert Compile Error: {}", GL20.glGetShaderInfoLog(vert));
            GL20.glDeleteShader(vert);
            return 0;
        }

        int frag = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(frag, fragSrc);
        GL20.glCompileShader(frag);
        if (GL20.glGetShaderi(frag, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] EASU Frag Compile Error: {}", GL20.glGetShaderInfoLog(frag));
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            return 0;
        }

        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vert);
        GL20.glAttachShader(prog, frag);
        GL20.glLinkProgram(prog);

        GL20.glDeleteShader(vert);
        GL20.glDeleteShader(frag);

        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] EASU Link Error: {}", GL20.glGetProgramInfoLog(prog));
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }
}
