package com.rumble.graphics.gsr;

import com.mojang.blaze3d.platform.GlStateManager;
import com.rumble.graphics.RumbleGraphics;
import com.rumble.graphics.sun.SunTracker;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL12;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.nio.ByteBuffer;

/**
 * High-Efficiency Downsampled Crepuscular Rays (Godrays) Pass for Adreno 740.
 * Decouples raymarching from the full-resolution fragment pass into a dedicated
 * low-resolution FBO (1/4 or 1/2 resolution), eliminating the massive fillrate
 * saturation and frame drops when looking towards the sun.
 */
public class GodrayPass {

    private int fboGodray = 0;
    private int texGodray = 0;
    private int currentWidth = 0;
    private int currentHeight = 0;
    private int currentDownscale = 4;

    private int godrayProgram = 0;

    private int locDiffuseSampler = -1;
    private int locDepthSampler = -1;
    private int locUseDepthTexture = -1;
    private int locSunScreenPos = -1;
    private int locSunVisibility = -1;
    private int locHorizonFade = -1;
    private int locIntensity = -1;
    private int locSteps = -1;

    private boolean initialized = false;
    private boolean failed = false;

    private static final String VERTEX_SRC = "#version 330 core\n"
            + "layout(location = 0) in vec2 inPosition;\n"
            + "layout(location = 1) in vec2 inTexCoord;\n"
            + "out vec2 texCoord;\n"
            + "void main() {\n"
            + "    texCoord = inTexCoord;\n"
            + "    gl_Position = vec4(inPosition, 0.0, 1.0);\n"
            + "}\n";

    private static final String GODRAY_FRAGMENT_SRC = "#version 330 core\n"
            + "in vec2 texCoord;\n"
            + "out vec4 fragColor;\n"
            + "\n"
            + "uniform sampler2D DiffuseSampler;\n"
            + "uniform sampler2D DepthSampler;\n"
            + "uniform int UseDepthTexture;\n"
            + "uniform vec2 SunScreenPos;\n"
            + "uniform float SunVisibility;\n"
            + "uniform float HorizonFade;\n"
            + "uniform float Intensity;\n"
            + "uniform int Steps;\n"
            + "\n"
            + "// Interleaved Gradient Noise for anti-banding jitter\n"
            + "float interleavedGradientNoise(vec2 pos) {\n"
            + "    return fract(52.9829189 * fract(dot(pos, vec2(0.06711056, 0.00583715))));\n"
            + "}\n"
            + "\n"
            + "void main() {\n"
            + "    if (SunVisibility <= 0.01 || HorizonFade <= 0.01 || Intensity <= 0.01) {\n"
            + "        fragColor = vec4(0.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    vec2 rayVec = SunScreenPos - texCoord;\n"
            + "    float dist = length(rayVec);\n"
            + "    if (dist > 1.45) {\n"
            + "        fragColor = vec4(0.0);\n"
            + "        return;\n"
            + "    }\n"
            + "\n"
            + "    float forwardScatter = 1.0 / (1.0 + dist * 1.5);\n"
            + "    int numSteps = clamp(Steps, 8, 20);\n"
            + "    vec2 stepVec = (rayVec / float(numSteps)) * 0.90;\n"
            + "    float dither = interleavedGradientNoise(gl_FragCoord.xy);\n"
            + "    vec2 sUV = texCoord + stepVec * dither;\n"
            + "\n"
            + "    float lightAccum = 0.0;\n"
            + "    float decay = 1.0;\n"
            + "    float decayRate = pow(0.35, 1.0 / float(numSteps));\n"
            + "\n"
            + "    for (int i = 0; i < 20; i++) {\n"
            + "        if (i >= numSteps) break;\n"
            + "        if (sUV.x >= 0.0 && sUV.x <= 1.0 && sUV.y >= 0.0 && sUV.y <= 1.0) {\n"
            + "            if (UseDepthTexture == 1) {\n"
            + "                float d = texture(DepthSampler, sUV).r;\n"
            + "                if (d >= 0.9999) {\n"
            + "                    lightAccum += 1.0 * decay;\n"
            + "                }\n"
            + "            } else {\n"
            + "                vec3 sCol = texture(DiffuseSampler, sUV).rgb;\n"
            + "                float lum = dot(sCol, vec3(0.299, 0.587, 0.114));\n"
            + "                float radiance = smoothstep(0.40, 0.92, lum);\n"
            + "                lightAccum += radiance * decay;\n"
            + "            }\n"
            + "        }\n"
            + "        sUV += stepVec;\n"
            + "        decay *= decayRate;\n"
            + "    }\n"
            + "\n"
            + "    float rayDensity = lightAccum / float(numSteps);\n"
            + "    // Protect the immediate sun disc from extreme radial blowout\n"
            + "    float centerMask = smoothstep(0.015, 0.12, dist);\n"
            + "    rayDensity *= mix(0.35, 1.0, centerMask);\n"
            + "\n"
            + "    vec3 dayColor = vec3(1.10, 1.00, 0.85);\n"
            + "    vec3 sunsetColor = vec3(1.30, 0.65, 0.28);\n"
            + "    float sunsetMix = 1.0 - smoothstep(0.12, 0.45, HorizonFade);\n"
            + "    vec3 rayColor = mix(dayColor, sunsetColor, sunsetMix);\n"
            + "    float distFade = 1.0 - smoothstep(0.0, 1.40, dist);\n"
            + "\n"
            + "    vec3 result = rayColor * (rayDensity * forwardScatter * distFade * HorizonFade * SunVisibility * (Intensity * 1.6));\n"
            + "    fragColor = vec4(clamp(result, 0.0, 0.85), 1.0);\n"
            + "}\n";

    public void init() {
        if (initialized || failed) return;

        godrayProgram = compileProgram(VERTEX_SRC, GODRAY_FRAGMENT_SRC);
        if (godrayProgram == 0) {
            failed = true;
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Failed to compile GodrayPass shader!");
            return;
        }

        locDiffuseSampler = GL20.glGetUniformLocation(godrayProgram, "DiffuseSampler");
        locDepthSampler = GL20.glGetUniformLocation(godrayProgram, "DepthSampler");
        locUseDepthTexture = GL20.glGetUniformLocation(godrayProgram, "UseDepthTexture");
        locSunScreenPos = GL20.glGetUniformLocation(godrayProgram, "SunScreenPos");
        locSunVisibility = GL20.glGetUniformLocation(godrayProgram, "SunVisibility");
        locHorizonFade = GL20.glGetUniformLocation(godrayProgram, "HorizonFade");
        locIntensity = GL20.glGetUniformLocation(godrayProgram, "Intensity");
        locSteps = GL20.glGetUniformLocation(godrayProgram, "Steps");

        initialized = true;
    }

    public void checkResize(int baseWidth, int baseHeight, int downscale) {
        int w = Math.max(1, baseWidth / downscale);
        int h = Math.max(1, baseHeight / downscale);

        if (w == currentWidth && h == currentHeight && downscale == currentDownscale && fboGodray != 0) {
            return;
        }

        destroyBuffers();

        currentWidth = w;
        currentHeight = h;
        currentDownscale = downscale;

        texGodray = GL11.glGenTextures();
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texGodray);
        GL11.glTexImage2D(GL11.GL_TEXTURE_2D, 0, GL11.GL_RGBA8, w, h, 0, GL11.GL_RGBA, GL11.GL_UNSIGNED_BYTE, (ByteBuffer) null);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_S, GL12.GL_CLAMP_TO_EDGE);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_WRAP_T, GL12.GL_CLAMP_TO_EDGE);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, 0);

        fboGodray = GL30.glGenFramebuffers();
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboGodray);
        GL30.glFramebufferTexture2D(GL30.GL_FRAMEBUFFER, GL30.GL_COLOR_ATTACHMENT0, GL11.GL_TEXTURE_2D, texGodray, 0);
        int status = GL30.glCheckFramebufferStatus(GL30.GL_FRAMEBUFFER);
        if (status != GL30.GL_FRAMEBUFFER_COMPLETE) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Godray FBO incomplete! Status: {}", status);
        }
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);
    }

    /**
     * Executes the low-resolution godrays raymarching pass.
     * @return Texture ID of the downsampled godrays texture.
     */
    public int render(int sourceColorTex, int depthTexId, boolean useDepth, int baseWidth, int baseHeight,
                      SunTracker sunTracker, float sunVisibility, float intensity, int steps, int downscale, int quadVao) {
        if (!initialized) {
            init();
            if (failed) return 0;
        }

        // Early termination if sun is occluded, below horizon, or behind player camera
        if (sunVisibility <= 0.01f || intensity <= 0.01f || sunTracker.getSunInFront() <= 0.01f || sunTracker.getHorizonFade() <= 0.01f) {
            return 0;
        }

        checkResize(baseWidth, baseHeight, downscale);
        if (fboGodray == 0 || texGodray == 0) return 0;

        // Prepare fullscreen pass states
        GlStateManager._disableDepthTest();
        GlStateManager._depthMask(false);
        GlStateManager._disableBlend();
        GlStateManager._disableCull();
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glColorMask(true, true, true, true);

        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, fboGodray);
        GlStateManager._viewport(0, 0, currentWidth, currentHeight);

        GL20.glUseProgram(godrayProgram);

        if (locSunScreenPos != -1) GL20.glUniform2f(locSunScreenPos, sunTracker.getScreenX(), sunTracker.getScreenY());
        if (locSunVisibility != -1) GL20.glUniform1f(locSunVisibility, sunVisibility);
        if (locHorizonFade != -1) GL20.glUniform1f(locHorizonFade, sunTracker.getHorizonFade());
        if (locIntensity != -1) GL20.glUniform1f(locIntensity, intensity);
        if (locSteps != -1) GL20.glUniform1i(locSteps, steps);

        // Bind source color to TEXTURE0
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, sourceColorTex);
        if (locDiffuseSampler != -1) GL20.glUniform1i(locDiffuseSampler, 0);

        // Bind depth texture to TEXTURE1 if available
        if (useDepth && depthTexId > 0 && GL11.glIsTexture(depthTexId)) {
            GL13.glActiveTexture(GL13.GL_TEXTURE1);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, depthTexId);
            if (locDepthSampler != -1) GL20.glUniform1i(locDepthSampler, 1);
            if (locUseDepthTexture != -1) GL20.glUniform1i(locUseDepthTexture, 1);
        } else {
            if (locUseDepthTexture != -1) GL20.glUniform1i(locUseDepthTexture, 0);
        }

        GL30.glBindVertexArray(quadVao);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
        GL30.glBindVertexArray(0);

        GL20.glUseProgram(0);
        GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, 0);

        return texGodray;
    }

    public int getTextureId() {
        return texGodray;
    }

    public int getWidth() {
        return currentWidth;
    }

    public int getHeight() {
        return currentHeight;
    }

    public void destroyBuffers() {
        if (fboGodray != 0) {
            GL30.glDeleteFramebuffers(fboGodray);
            fboGodray = 0;
        }
        if (texGodray != 0) {
            GL11.glDeleteTextures(texGodray);
            texGodray = 0;
        }
        currentWidth = 0;
        currentHeight = 0;
    }

    public void destroy() {
        destroyBuffers();
        if (godrayProgram != 0) {
            GL20.glDeleteProgram(godrayProgram);
            godrayProgram = 0;
        }
        initialized = false;
        failed = false;
    }

    private static int compileProgram(String vertSrc, String fragSrc) {
        int vert = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        GL20.glShaderSource(vert, vertSrc);
        GL20.glCompileShader(vert);
        if (GL20.glGetShaderi(vert, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Godray Vert Shader Error: {}", GL20.glGetShaderInfoLog(vert));
            GL20.glDeleteShader(vert);
            return 0;
        }

        int frag = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        GL20.glShaderSource(frag, fragSrc);
        GL20.glCompileShader(frag);
        if (GL20.glGetShaderi(frag, GL20.GL_COMPILE_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Godray Frag Shader Error: {}", GL20.glGetShaderInfoLog(frag));
            GL20.glDeleteShader(vert);
            GL20.glDeleteShader(frag);
            return 0;
        }

        int prog = GL20.glCreateProgram();
        GL20.glAttachShader(prog, vert);
        GL20.glAttachShader(prog, frag);
        GL20.glLinkProgram(prog);

        GL20.glDeleteShader(vert);
        GL20.glDeleteShader(frag);

        if (GL20.glGetProgrami(prog, GL20.GL_LINK_STATUS) == 0) {
            RumbleGraphics.LOGGER.error("[RumbleGraphics] Godray Program Link Error: {}", GL20.glGetProgramInfoLog(prog));
            GL20.glDeleteProgram(prog);
            return 0;
        }
        return prog;
    }
}
