package com.rumble.graphics.gsr;

import com.mojang.blaze3d.pipeline.RenderTarget;

/**
 * SnapdragonGSR Facade.
 * Maintains API compatibility while routing execution to the high-performance
 * modular PostProcessPipeline.
 */
public class SnapdragonGSR {

    public static void process(RenderTarget mainTarget, float tickDelta) {
        PostProcessPipeline.render(mainTarget, tickDelta);
    }

    public static void destroy() {
        PostProcessPipeline.destroy();
    }
}
