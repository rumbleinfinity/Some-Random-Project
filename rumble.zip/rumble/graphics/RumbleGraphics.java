package com.rumble.graphics;

import com.mojang.blaze3d.platform.InputConstants;
import com.rumble.graphics.config.RumbleConfig;
import com.rumble.graphics.gsr.RenderScaleManager;
import com.rumble.graphics.gsr.SnapdragonGSR;
import com.rumble.graphics.gui.RumbleDebugHud;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RumbleGraphics implements ClientModInitializer {
    public static final String MOD_ID = "rumblegraphics";
    public static final String MOD_NAME = "RumbleGraphics";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    private static KeyMapping keyCycleDebug;
    private static KeyMapping keyToggleHud;

    @Override
    public void onInitializeClient() {
        RumbleConfig.load();

        // Register Diagnostic HUD render callback
        HudRenderCallback.EVENT.register(RumbleDebugHud::render);

        // Register Keyboard Shortcuts for Developer & User convenience
        keyCycleDebug = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.rumblegraphics.cycle_debug",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_F6,
                "category.rumblegraphics"
        ));

        keyToggleHud = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.rumblegraphics.toggle_hud",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_F7,
                "category.rumblegraphics"
        ));

        // Listen for keypress events to cycle debug mode or toggle HUD
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            while (keyCycleDebug.consumeClick()) {
                RumbleConfig config = RumbleConfig.get();
                config.debugMode = (config.debugMode + 1) % 11;
                RumbleConfig.save();
                client.player.displayClientMessage(
                        Component.literal("§6[RumbleGraphics] §fDebug Mode: §e" + RumbleDebugHud.getDebugModeName(config.debugMode)),
                        true
                );
            }

            while (keyToggleHud.consumeClick()) {
                RumbleConfig config = RumbleConfig.get();
                config.showDebugHud = !config.showDebugHud;
                RumbleConfig.save();
                client.player.displayClientMessage(
                        Component.literal("§6[RumbleGraphics] §fDebug HUD: " + (config.showDebugHud ? "§aENABLED" : "§cDISABLED")),
                        true
                );
            }
        });

        // Safe resource cleanup when game closes to prevent GPU memory leaks
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
            RenderScaleManager.destroy();
            SnapdragonGSR.destroy();
        });

        LOGGER.info("[{}] Initialized Mobile Graphics Extension for Sodium", MOD_NAME);
        LOGGER.info("[{}] Edge-Adaptive Contrast Sharpening (EACS): {}",
                MOD_NAME, RumbleConfig.get().enableSnapdragonGSR ? "ACTIVE" : "DISABLED");
        LOGGER.info("[{}] Active Features: Master={}, Waving={}, Water={}, Shadows={}, Godrays={}, Bloom={}, Flare={}, Tonemap={}",
                MOD_NAME,
                RumbleConfig.get().masterEnabled,
                RumbleConfig.get().enableWaving,
                RumbleConfig.get().enableWater,
                RumbleConfig.get().enableContactAO,
                RumbleConfig.get().enableGodrays,
                RumbleConfig.get().enableBloom,
                RumbleConfig.get().enableLensFlare,
                RumbleConfig.get().enableTonemapping);
    }
}
