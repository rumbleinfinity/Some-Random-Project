package com.rumble.graphics.gl;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.system.MemoryStack;

/**
 * Robust OpenGL State Guard for MobileGlues (OpenGL 3.3/4.0 Core on Android/ARM64).
 * Captures and restores every render state modified by post-processing passes:
 * - Separate Read & Draw Framebuffers
 * - Viewport & Scissor box
 * - Active texture unit & Texture bindings for all modified units (TEXTURE0 to TEXTURE3)
 * - Shader program, VAO, Array Buffer (VBO), Element Array Buffer (EBO)
 * - Blend enable, separate RGB/Alpha blend functions & equations
 * - Depth test enable, depth func & depth writemask
 * - Full RGBA color writemask & Face culling
 */
public class GLStateManagerHelper {

    private static final int NUM_MANAGED_TEXTURES = 6;

    private int prevDrawFbo;
    private int prevReadFbo;
    private int prevProgram;
    private int prevVao;
    private int prevArrayBuffer;
    private int prevElementBuffer;
    private int prevActiveTexture;
    private final int[] prevTextures2D = new int[NUM_MANAGED_TEXTURES];
    private final int[] prevViewport = new int[4];
    private final int[] prevScissorBox = new int[4];

    private boolean prevBlend;
    private int prevBlendSrcRgb;
    private int prevBlendDstRgb;
    private int prevBlendSrcAlpha;
    private int prevBlendDstAlpha;
    private int prevBlendEqRgb;
    private int prevBlendEqAlpha;

    private boolean prevDepthTest;
    private int prevDepthFunc;
    private boolean prevDepthMask;

    private boolean prevCullFace;
    private boolean prevScissorTest;
    private boolean prevColorMaskR;
    private boolean prevColorMaskG;
    private boolean prevColorMaskB;
    private boolean prevColorMaskA;

    public void capture() {
        try (MemoryStack stack = MemoryStack.stackPush()) {
            // 1. Framebuffers
            prevDrawFbo = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
            prevReadFbo = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);

            // 2. Program, Vertex Array & Buffers
            prevProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
            prevVao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
            prevArrayBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
            prevElementBuffer = GL11.glGetInteger(GL15.GL_ELEMENT_ARRAY_BUFFER_BINDING);

            // 3. Texture Units & Bindings
            prevActiveTexture = GL11.glGetInteger(GL13.GL_ACTIVE_TEXTURE);
            for (int i = 0; i < NUM_MANAGED_TEXTURES; i++) {
                GL13.glActiveTexture(GL13.GL_TEXTURE0 + i);
                prevTextures2D[i] = GL11.glGetInteger(GL11.GL_TEXTURE_BINDING_2D);
            }
            GL13.glActiveTexture(prevActiveTexture);

            // 4. Viewport & Scissor
            IntBuffer vpBuf = stack.mallocInt(4);
            GL11.glGetIntegerv(GL11.GL_VIEWPORT, vpBuf);
            vpBuf.get(prevViewport);

            prevScissorTest = GL11.glIsEnabled(GL11.GL_SCISSOR_TEST);
            IntBuffer scBuf = stack.mallocInt(4);
            GL11.glGetIntegerv(GL11.GL_SCISSOR_BOX, scBuf);
            scBuf.get(prevScissorBox);

            // 5. Blending
            prevBlend = GL11.glIsEnabled(GL11.GL_BLEND);
            prevBlendSrcRgb = GL11.glGetInteger(GL14.GL_BLEND_SRC_RGB);
            prevBlendDstRgb = GL11.glGetInteger(GL14.GL_BLEND_DST_RGB);
            prevBlendSrcAlpha = GL11.glGetInteger(GL14.GL_BLEND_SRC_ALPHA);
            prevBlendDstAlpha = GL11.glGetInteger(GL14.GL_BLEND_DST_ALPHA);
            prevBlendEqRgb = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_RGB);
            prevBlendEqAlpha = GL11.glGetInteger(GL20.GL_BLEND_EQUATION_ALPHA);

            // 6. Depth
            prevDepthTest = GL11.glIsEnabled(GL11.GL_DEPTH_TEST);
            prevDepthFunc = GL11.glGetInteger(GL11.GL_DEPTH_FUNC);
            prevDepthMask = GL11.glGetBoolean(GL11.GL_DEPTH_WRITEMASK);

            // 7. Culling & Color Write Mask
            prevCullFace = GL11.glIsEnabled(GL11.GL_CULL_FACE);

            ByteBuffer cmBuf = stack.malloc(4);
            GL11.glGetBooleanv(GL11.GL_COLOR_WRITEMASK, cmBuf);
            prevColorMaskR = cmBuf.get(0) != 0;
            prevColorMaskG = cmBuf.get(1) != 0;
            prevColorMaskB = cmBuf.get(2) != 0;
            prevColorMaskA = cmBuf.get(3) != 0;
        }
    }

    /**
     * Prepares standard fullscreen quad state so lingering states from Minecraft/Sodium
     * (such as scissor clipping or disabled color masks) do not distort the post-processing.
     */
    public void prepareFullscreenPass(int width, int height) {
        GlStateManager._viewport(0, 0, width, height);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.disableBlend();
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
        GL11.glColorMask(true, true, true, true);
    }

    public void restore() {
        // 1. Restore Vertex Buffers & Arrays
        GL15.glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, prevElementBuffer);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, prevArrayBuffer);
        GL30.glBindVertexArray(prevVao);

        // 2. Restore Shader Program
        GL20.glUseProgram(prevProgram);

        // 3. Restore all Texture Unit Bindings
        for (int i = 0; i < NUM_MANAGED_TEXTURES; i++) {
            GL13.glActiveTexture(GL13.GL_TEXTURE0 + i);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, prevTextures2D[i]);
        }
        GL13.glActiveTexture(prevActiveTexture);

        // 4. Restore Framebuffers
        if (prevDrawFbo == prevReadFbo) {
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, prevDrawFbo);
        } else {
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, prevDrawFbo);
            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, prevReadFbo);
        }

        // 5. Restore Viewport & Scissor Box
        GlStateManager._viewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
        GL11.glScissor(prevScissorBox[0], prevScissorBox[1], prevScissorBox[2], prevScissorBox[3]);
        if (prevScissorTest) {
            GL11.glEnable(GL11.GL_SCISSOR_TEST);
        } else {
            GL11.glDisable(GL11.GL_SCISSOR_TEST);
        }

        // 6. Restore Blend State & Equations
        if (prevBlend) {
            RenderSystem.enableBlend();
            GL14.glBlendFuncSeparate(prevBlendSrcRgb, prevBlendDstRgb, prevBlendSrcAlpha, prevBlendDstAlpha);
            GL20.glBlendEquationSeparate(prevBlendEqRgb, prevBlendEqAlpha);
        } else {
            RenderSystem.disableBlend();
        }

        // 7. Restore Depth State
        if (prevDepthTest) {
            RenderSystem.enableDepthTest();
            GL11.glDepthFunc(prevDepthFunc);
        } else {
            RenderSystem.disableDepthTest();
        }
        RenderSystem.depthMask(prevDepthMask);

        // 8. Restore Culling & Color Write Mask
        if (prevCullFace) {
            RenderSystem.enableCull();
        } else {
            RenderSystem.disableCull();
        }
        GL11.glColorMask(prevColorMaskR, prevColorMaskG, prevColorMaskB, prevColorMaskA);
    }
}
