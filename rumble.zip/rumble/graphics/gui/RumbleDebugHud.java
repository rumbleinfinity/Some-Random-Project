package com.rumble.graphics.gui;

import com.rumble.graphics.config.RumbleConfig;
import com.rumble.graphics.gsr.PostProcessPipeline;
import com.rumble.graphics.gsr.RenderScaleManager;
import com.rumble.graphics.mixin.GameRendererMixin;
import com.rumble.graphics.mixin.ShaderChunkRendererMixin;
import com.rumble.graphics.shader.RumbleShaderPatcher;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * In-game diagnostic overlay that displays real-time rendering pipeline status,
 * Mixin activity, shader compilation, framebuffer dimensions, and sun tracking metrics.
 * Designed to have ZERO performance impact when disabled.
 */
public class RumbleDebugHud {

    public static String getDebugModeName(int mode) {
        return switch (mode) {
            case 0 -> "0: Disabled (Normal Beauty Composite)";
            case 1 -> "1: Original Scene (Vanilla Passthrough)";
            case 2 -> "2: Bloom Extraction Only";
            case 3 -> "3: Bloom Multi-Scale Blur Only";
            case 4 -> "4: Godrays Only (Isolated on Black)";
            case 5 -> "5: Sun Position & Marker Reticle";
            case 6 -> "6: Sun Occlusion Visualization";
            case 7 -> "7: Sharpening Edge Contrast Map";
            case 8 -> "8: Color Grading Only";
            case 9 -> "9: Volumetric Clouds Only";
            case 10 -> "10: Split Screen (Left: Vanilla, Right: Rumble)";
            default -> "Unknown";
        };
    }

    public static void render(GuiGraphics guiGraphics, float tickDelta) {
        RumbleConfig config = RumbleConfig.get();
        if (!config.masterEnabled || (!config.showDebugHud && config.debugMode == 0)) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.level == null) {
            return;
        }

        Font font = mc.font;
        List<String> lines = new ArrayList<>();

        lines.add("§6[RumbleGraphics Debug HUD] §7(Snapdragon 8 Gen 2 / Adreno 740)");
        lines.add("§fPipeline: " + (PostProcessPipeline.isPipelineActive() ? "§aACTIVE" : "§cBYPASSED")
                + " §7| Frame: #" + PostProcessPipeline.getFrameCount()
                + " §7| Pass GPU: §e" + String.format(Locale.ROOT, "%.2f ms", PostProcessPipeline.getLastExecutionNanos() / 1_000_000.0));

        lines.add("§fGameRendererMixin: §aHOOKED §7(" + GameRendererMixin.getRumbleRenderHookCalls() + " calls)");
        lines.add("§fSodium Integration: " + (ShaderChunkRendererMixin.isRumbleSodiumActive()
                ? "§aACTIVE (§e" + ShaderChunkRendererMixin.getRumbleLastPassName() + "§a)" : "§7INACTIVE"));

        lines.add("§fShaders: PostProcess=" + (PostProcessPipeline.areShadersCompiled() ? "§aOK" : "§cFAIL")
                + " §7| Sodium: VSH=" + (RumbleShaderPatcher.isVertexShaderPatched() ? "§aOK" : "§eVANILLA")
                + " FSH=" + (RumbleShaderPatcher.isFragmentShaderPatched() ? "§aOK" : "§eVANILLA"));

        if (RenderScaleManager.getActiveScalePercent() < 100) {
            lines.add("§fResolution Scale: §a" + RenderScaleManager.getActiveScalePercent() + "% (EASU Reconstruction)"
                    + " §7| 3D: §e" + RenderScaleManager.getCurrentScaledWidth() + "x" + RenderScaleManager.getCurrentScaledHeight()
                    + " §7-> GUI: §b" + mc.getWindow().getWidth() + "x" + mc.getWindow().getHeight());
        } else {
            lines.add("§fResolution: §b" + PostProcessPipeline.getLastWidth() + "x" + PostProcessPipeline.getLastHeight()
                    + " §a(100% Native)");
        }

        lines.add("§fGodrays: " + (config.enableGodrays ? "§aON §7(FBO: 1/" + config.godrayDownscale + " res, " + config.godrayQuality + " steps)" : "§7OFF")
                + " | Bloom: " + (config.enableBloom ? "§aON §7(L0-L" + (config.bloomQuality - 1) + ", T=" + config.bloomThreshold + "%)" : "§7OFF")
                + " | Clouds: " + (config.enableClouds ? "§aON §7(1/4 res)" : "§7OFF"));

        lines.add("§fSun Screen UV: §b("
                + String.format(Locale.ROOT, "%.3f, %.3f", PostProcessPipeline.getSunTracker().getScreenX(), PostProcessPipeline.getSunTracker().getScreenY())
                + ") §7| InFront: " + (PostProcessPipeline.getSunTracker().getSunInFront() > 0.5f ? "§aYES" : "§cNO")
                + " §7| HorizonFade: §e" + String.format(Locale.ROOT, "%.2f", PostProcessPipeline.getSunTracker().getHorizonFade()));

        lines.add("§fSun Occlusion: §e" + String.format(Locale.ROOT, "%.2f", PostProcessPipeline.getSunOcclusion().getSmoothOcclusion())
                + " §7(" + PostProcessPipeline.getSunOcclusion().getOcclusionStatus() + ")");

        lines.add("§fFeatures: Flare=" + (config.enableLensFlare ? "§aON" : "§7OFF")
                + " Water=" + (config.enableWater ? "§aON" : "§7OFF")
                + " Waving=" + (config.enableWaving ? "§aON" : "§7OFF")
                + " GSR=" + (config.enableSnapdragonGSR ? "§aON" : "§7OFF")
                + " ACES=" + (config.enableTonemapping ? "§aON" : "§7OFF"));

        lines.add("§fDebug Mode: §e" + getDebugModeName(config.debugMode));

        int x = 6;
        int y = 6;
        int maxTextWidth = 0;
        for (String line : lines) {
            maxTextWidth = Math.max(maxTextWidth, font.width(line));
        }

        int boxWidth = maxTextWidth + 8;
        int boxHeight = lines.size() * 11 + 6;

        guiGraphics.fill(x - 2, y - 2, x + boxWidth, y + boxHeight, 0x90000000);

        for (int i = 0; i < lines.size(); i++) {
            guiGraphics.drawString(font, lines.get(i), x + 2, y + 2 + i * 11, 0xFFFFFFFF, true);
        }
    }
}
