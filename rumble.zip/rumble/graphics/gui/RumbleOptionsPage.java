package com.rumble.graphics.gui;

import com.google.common.collect.ImmutableList;
import com.rumble.graphics.config.RumbleConfig;
import me.jellysquid.mods.sodium.client.gui.options.OptionFlag;
import me.jellysquid.mods.sodium.client.gui.options.OptionGroup;
import me.jellysquid.mods.sodium.client.gui.options.OptionImpl;
import me.jellysquid.mods.sodium.client.gui.options.OptionPage;
import me.jellysquid.mods.sodium.client.gui.options.control.ControlValueFormatter;
import me.jellysquid.mods.sodium.client.gui.options.control.SliderControl;
import me.jellysquid.mods.sodium.client.gui.options.control.TickBoxControl;
import me.jellysquid.mods.sodium.client.gui.options.storage.OptionStorage;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * Creates the options tabs inside Sodium's video settings menu.
 * Tab 1: Super Resolution & Render Scale (EASU Spatial Upscaling + EACS Sharpening)
 * Tab 2: Visual Effects (Godrays, Lens Flare, Bloom, Volumetric Clouds, Foliage & Water, Color Grading)
 * Tab 3: Diagnostics & Debug Suite (Visual Debug Modes & Real-Time In-Game HUD)
 */
public class RumbleOptionsPage {

    private static final OptionStorage<RumbleConfig> STORAGE = new OptionStorage<>() {
        @Override
        public RumbleConfig getData() {
            return RumbleConfig.get();
        }

        @Override
        public void save() {
            RumbleConfig.save();
        }
    };

    /** Tab 1: Super Resolution & Render Scale */
    public static OptionPage createSuperResolutionPage() {
        List<OptionGroup> groups = new ArrayList<>();

        // Group 1: Resolution Scaling
        OptionGroup.Builder scaleGroup = OptionGroup.createBuilder();
        scaleGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.render_scale"))
                .setTooltip(Component.translatable("rumblegraphics.options.render_scale.tooltip"))
                .setControl(opt -> new SliderControl(opt, 50, 100, 5, val -> {
                    if (val == 100) return Component.literal("100% (Native)");
                    if (val == 90) return Component.literal("90% (Quality)");
                    if (val == 75) return Component.literal("75% (Balanced)");
                    if (val == 67) return Component.literal("67% (Performance)");
                    if (val == 50) return Component.literal("50% (Ultra Perf)");
                    return Component.literal(val + "%");
                }))
                .setBinding((config, val) -> config.renderScale = val, config -> config.renderScale)
                .build()
        );
        groups.add(scaleGroup.build());

        // Group 2: Edge-Adaptive Sharpening (Snapdragon GSR / EACS)
        OptionGroup.Builder gsrGroup = OptionGroup.createBuilder();
        gsrGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.gsr_enabled"))
                .setTooltip(Component.translatable("rumblegraphics.options.gsr_enabled.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableSnapdragonGSR = val, config -> config.enableSnapdragonGSR)
                .build()
        );

        gsrGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.gsr_sharpness"))
                .setTooltip(Component.translatable("rumblegraphics.options.gsr_sharpness.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.gsrSharpness = val, config -> config.gsrSharpness)
                .build()
        );

        gsrGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.gsr_sensitivity"))
                .setTooltip(Component.translatable("rumblegraphics.options.gsr_sensitivity.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.gsrSensitivity = val, config -> config.gsrSensitivity)
                .build()
        );
        groups.add(gsrGroup.build());

        return new OptionPage(Component.translatable("rumblegraphics.options.tab.super_resolution"), ImmutableList.copyOf(groups));
    }

    /** Tab 2: Visual Effects */
    public static OptionPage createEffectsPage() {
        List<OptionGroup> groups = new ArrayList<>();

        // Group 1: Master Control & Presets
        OptionGroup.Builder masterGroup = OptionGroup.createBuilder();
        masterGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.master_enabled"))
                .setTooltip(Component.translatable("rumblegraphics.options.master_enabled.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.masterEnabled = val, config -> config.masterEnabled)
                .setFlags(OptionFlag.REQUIRES_RENDERER_RELOAD)
                .build()
        );
        masterGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.preset"))
                .setTooltip(Component.translatable("rumblegraphics.options.preset.tooltip"))
                .setControl(opt -> new SliderControl(opt, 1, 3, 1, val -> switch (val) {
                    case 1 -> Component.literal("Low");
                    case 2 -> Component.literal("Medium");
                    case 3 -> Component.literal("High (Adreno 740)");
                    default -> Component.literal("Custom");
                }))
                .setBinding((config, val) -> config.applyPreset(val), config -> config.qualityPreset)
                .build()
        );
        groups.add(masterGroup.build());

        // Group 2: Atmosphere & Godrays
        OptionGroup.Builder godrayGroup = OptionGroup.createBuilder();
        godrayGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.godrays"))
                .setTooltip(Component.translatable("rumblegraphics.options.godrays.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableGodrays = val, config -> config.enableGodrays)
                .build()
        );
        godrayGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.godray_intensity"))
                .setTooltip(Component.translatable("rumblegraphics.options.godray_intensity.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.godrayIntensity = val, config -> config.godrayIntensity)
                .build()
        );
        godrayGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.godray_quality"))
                .setTooltip(Component.translatable("rumblegraphics.options.godray_quality.tooltip"))
                .setControl(opt -> new SliderControl(opt, 8, 20, 2, val -> Component.literal(val + " steps")))
                .setBinding((config, val) -> config.godrayQuality = val, config -> config.godrayQuality)
                .build()
        );
        godrayGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.godray_downscale"))
                .setTooltip(Component.translatable("rumblegraphics.options.godray_downscale.tooltip"))
                .setControl(opt -> new SliderControl(opt, 2, 4, 2, val -> val == 2 ? Component.literal("1/2 Resolution") : Component.literal("1/4 Res (Fast Adreno)")))
                .setBinding((config, val) -> config.godrayDownscale = val, config -> config.godrayDownscale)
                .build()
        );
        groups.add(godrayGroup.build());

        // Group 3: Cinematic Optical Lens Flare
        OptionGroup.Builder flareGroup = OptionGroup.createBuilder();
        flareGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.lens_flare"))
                .setTooltip(Component.translatable("rumblegraphics.options.lens_flare.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableLensFlare = val, config -> config.enableLensFlare)
                .build()
        );
        flareGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.lens_flare_intensity"))
                .setTooltip(Component.translatable("rumblegraphics.options.lens_flare_intensity.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.lensFlareIntensity = val, config -> config.lensFlareIntensity)
                .build()
        );
        flareGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.lens_flare_halo"))
                .setTooltip(Component.translatable("rumblegraphics.options.lens_flare_halo.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.lensFlareHaloIntensity = val, config -> config.lensFlareHaloIntensity)
                .build()
        );
        flareGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.lens_flare_ghost"))
                .setTooltip(Component.translatable("rumblegraphics.options.lens_flare_ghost.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.lensFlareGhostIntensity = val, config -> config.lensFlareGhostIntensity)
                .build()
        );
        flareGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.lens_flare_streak"))
                .setTooltip(Component.translatable("rumblegraphics.options.lens_flare_streak.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.lensFlareStreakIntensity = val, config -> config.lensFlareStreakIntensity)
                .build()
        );
        groups.add(flareGroup.build());

        // Group 4: Multi-Scale Bloom
        OptionGroup.Builder bloomGroup = OptionGroup.createBuilder();
        bloomGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.bloom"))
                .setTooltip(Component.translatable("rumblegraphics.options.bloom.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableBloom = val, config -> config.enableBloom)
                .build()
        );
        bloomGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.bloom_intensity"))
                .setTooltip(Component.translatable("rumblegraphics.options.bloom_intensity.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.bloomIntensity = val, config -> config.bloomIntensity)
                .build()
        );
        bloomGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.bloom_threshold"))
                .setTooltip(Component.translatable("rumblegraphics.options.bloom_threshold.tooltip"))
                .setControl(opt -> new SliderControl(opt, 20, 90, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.bloomThreshold = val, config -> config.bloomThreshold)
                .build()
        );
        bloomGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.bloom_quality"))
                .setTooltip(Component.translatable("rumblegraphics.options.bloom_quality.tooltip"))
                .setControl(opt -> new SliderControl(opt, 2, 4, 1, val -> Component.literal(val == 2 ? "Low" : (val == 3 ? "Medium" : "High"))))
                .setBinding((config, val) -> config.bloomQuality = val, config -> config.bloomQuality)
                .build()
        );
        groups.add(bloomGroup.build());

        // Group 5: Volumetric Clouds
        OptionGroup.Builder cloudGroup = OptionGroup.createBuilder();
        cloudGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.clouds"))
                .setTooltip(Component.translatable("rumblegraphics.options.clouds.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableClouds = val, config -> config.enableClouds)
                .build()
        );
        cloudGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.cloud_density"))
                .setTooltip(Component.translatable("rumblegraphics.options.cloud_density.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.cloudDensity = val, config -> config.cloudDensity)
                .build()
        );
        cloudGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.cloud_quality"))
                .setTooltip(Component.translatable("rumblegraphics.options.cloud_quality.tooltip"))
                .setControl(opt -> new SliderControl(opt, 1, 3, 1, val -> switch (val) {
                    case 1 -> Component.literal("Low (6 steps)");
                    case 2 -> Component.literal("Medium (8 steps)");
                    case 3 -> Component.literal("High (12 steps)");
                    default -> Component.literal("Custom");
                }))
                .setBinding((config, val) -> config.cloudQuality = val, config -> config.cloudQuality)
                .build()
        );
        cloudGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.cloud_speed"))
                .setTooltip(Component.translatable("rumblegraphics.options.cloud_speed.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.cloudSpeed = val, config -> config.cloudSpeed)
                .build()
        );
        groups.add(cloudGroup.build());

        // Group 6: Foliage & Water
        OptionGroup.Builder foliageWaterGroup = OptionGroup.createBuilder();
        foliageWaterGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.waving"))
                .setTooltip(Component.translatable("rumblegraphics.options.waving.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableWaving = val, config -> config.enableWaving)
                .setFlags(OptionFlag.REQUIRES_RENDERER_RELOAD)
                .build()
        );
        foliageWaterGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.water"))
                .setTooltip(Component.translatable("rumblegraphics.options.water.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableWater = val, config -> config.enableWater)
                .setFlags(OptionFlag.REQUIRES_RENDERER_RELOAD)
                .build()
        );
        foliageWaterGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.contact_shadows"))
                .setTooltip(Component.translatable("rumblegraphics.options.contact_shadows.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableContactAO = val, config -> config.enableContactAO)
                .setFlags(OptionFlag.REQUIRES_RENDERER_RELOAD)
                .build()
        );
        foliageWaterGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.skylight_shadows"))
                .setTooltip(Component.translatable("rumblegraphics.options.skylight_shadows.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableSkylightShadows = val, config -> config.enableSkylightShadows)
                .setFlags(OptionFlag.REQUIRES_RENDERER_RELOAD)
                .build()
        );
        foliageWaterGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.shadow_intensity"))
                .setTooltip(Component.translatable("rumblegraphics.options.shadow_intensity.tooltip"))
                .setControl(opt -> new SliderControl(opt, 10, 100, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.shadowIntensity = val, config -> config.shadowIntensity)
                .setFlags(OptionFlag.REQUIRES_RENDERER_RELOAD)
                .build()
        );
        groups.add(foliageWaterGroup.build());

        // Group 7: Color Grading & Tonemapping
        OptionGroup.Builder colorGroup = OptionGroup.createBuilder();
        colorGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.tonemapping"))
                .setTooltip(Component.translatable("rumblegraphics.options.tonemapping.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableTonemapping = val, config -> config.enableTonemapping)
                .build()
        );
        colorGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.vibrance"))
                .setTooltip(Component.translatable("rumblegraphics.options.vibrance.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.enableVibrance = val, config -> config.enableVibrance)
                .build()
        );
        colorGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.exposure"))
                .setTooltip(Component.translatable("rumblegraphics.options.exposure.tooltip"))
                .setControl(opt -> new SliderControl(opt, 50, 150, 5, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.colorExposure = val, config -> config.colorExposure)
                .build()
        );
        colorGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.contrast"))
                .setTooltip(Component.translatable("rumblegraphics.options.contrast.tooltip"))
                .setControl(opt -> new SliderControl(opt, 50, 150, 2, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.colorContrast = val, config -> config.colorContrast)
                .build()
        );
        colorGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.saturation"))
                .setTooltip(Component.translatable("rumblegraphics.options.saturation.tooltip"))
                .setControl(opt -> new SliderControl(opt, 50, 150, 2, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.colorSaturation = val, config -> config.colorSaturation)
                .build()
        );
        colorGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.temperature"))
                .setTooltip(Component.translatable("rumblegraphics.options.temperature.tooltip"))
                .setControl(opt -> new SliderControl(opt, 50, 150, 2, ControlValueFormatter.percentage()))
                .setBinding((config, val) -> config.colorTemperature = val, config -> config.colorTemperature)
                .build()
        );
        groups.add(colorGroup.build());

        return new OptionPage(Component.translatable("rumblegraphics.options.tab.effects"), ImmutableList.copyOf(groups));
    }

    /** Tab 3: Diagnostics & Visual Debug Suite */
    public static OptionPage createDiagnosticsPage() {
        List<OptionGroup> groups = new ArrayList<>();

        OptionGroup.Builder debugGroup = OptionGroup.createBuilder();
        debugGroup.add(OptionImpl.createBuilder(Integer.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.debug_mode"))
                .setTooltip(Component.translatable("rumblegraphics.options.debug_mode.tooltip"))
                .setControl(opt -> new SliderControl(opt, 0, 10, 1, val -> switch (val) {
                    case 0 -> Component.literal("0: Disabled (Normal)");
                    case 1 -> Component.literal("1: Original Scene");
                    case 2 -> Component.literal("2: Bloom Extract");
                    case 3 -> Component.literal("3: Bloom Blur");
                    case 4 -> Component.literal("4: Godrays Only");
                    case 5 -> Component.literal("5: Sun Marker");
                    case 6 -> Component.literal("6: Sun Occlusion");
                    case 7 -> Component.literal("7: Sharpening Edge");
                    case 8 -> Component.literal("8: Color Grading");
                    case 9 -> Component.literal("9: Clouds Only");
                    case 10 -> Component.literal("10: Split Screen");
                    default -> Component.literal("Unknown");
                }))
                .setBinding((config, val) -> config.debugMode = val, config -> config.debugMode)
                .build()
        );
        debugGroup.add(OptionImpl.createBuilder(Boolean.class, STORAGE)
                .setName(Component.translatable("rumblegraphics.options.debug_hud"))
                .setTooltip(Component.translatable("rumblegraphics.options.debug_hud.tooltip"))
                .setControl(TickBoxControl::new)
                .setBinding((config, val) -> config.showDebugHud = val, config -> config.showDebugHud)
                .build()
        );
        groups.add(debugGroup.build());

        return new OptionPage(Component.translatable("rumblegraphics.options.tab.diagnostics"), ImmutableList.copyOf(groups));
    }
}
