package com.rumble.graphics.sun;

import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * High-precision mathematical celestial tracker.
 * Computes exact Screen-Space UV coordinates, Camera Space depth, and Horizon visibility.
 * Synchronizes with Minecraft 1.20.1's active 3D perspective projection matrix via GameRenderer.
 * Zero-allocation design with reusable matrix and vector buffers.
 */
public class SunTracker {

    // Captured actual 3D projection matrix from Minecraft's GameRenderer.resetProjectionMatrix
    private static final Matrix4f capturedProj = new Matrix4f();
    private static volatile boolean hasCapturedProj = false;

    // Output variables
    private float screenX = 0.5f;
    private float screenY = 0.5f;
    private float sunInFront = 0.0f;
    private float horizonFade = 0.0f;

    // Normalized world sun direction components (East-West X, Up Y, North-South Z)
    private double sunDirX = 0.0;
    private double sunDirY = 1.0;
    private double sunDirZ = 0.0;

    // Zero-allocation reusable buffers
    private final Matrix4f modelView = new Matrix4f();
    private final Matrix4f fallbackProj = new Matrix4f();
    private final Vector4f worldSunDir = new Vector4f();
    private final Vector4f camSunDir = new Vector4f();
    private final Vector4f clipSun = new Vector4f();

    /**
     * Called from GameRendererMixin when Minecraft sets its 3D perspective projection matrix.
     */
    public static void setCapturedProjectionMatrix(Matrix4f proj) {
        if (proj != null) {
            capturedProj.set(proj);
            hasCapturedProj = true;
        }
    }

    public void update(Minecraft mc, float tickDelta, int viewWidth, int viewHeight) {
        if (mc.level == null || mc.gameRenderer == null || mc.player == null) {
            resetCoordinates();
            return;
        }

        try {
            Camera camera = mc.gameRenderer.getMainCamera();
            float skyAngle = mc.level.getTimeOfDay(tickDelta);

            // 1. World Celestial Sun Direction
            // In Minecraft, celestial angle theta runs 0.0 (noon) to 1.0 (next noon).
            // Sun rises in East (+X), peaks at noon (+Y), sets in West (-X).
            double phi = skyAngle * 2.0 * Math.PI;
            sunDirX = -Math.sin(phi);
            sunDirY = Math.cos(phi);
            sunDirZ = 0.0;

            // Horizon fade: 1.0 during bright day, smoothly fades to 0.0 near and below horizon
            horizonFade = Math.max(0.0f, Math.min(1.0f, (float) sunDirY * 3.5f));

            // 2. Camera View Transform (matches GameRenderer.renderLevel camera orientation)
            modelView.identity();
            modelView.rotate((float) Math.toRadians(camera.getXRot()), 1.0f, 0.0f, 0.0f);
            modelView.rotate((float) Math.toRadians(camera.getYRot() + 180.0f), 0.0f, 1.0f, 0.0f);

            // Transform world sun direction vector (w = 0) into camera space
            worldSunDir.set((float) sunDirX, (float) sunDirY, (float) sunDirZ, 0.0f);
            modelView.transform(worldSunDir, camSunDir);

            // In OpenGL/Minecraft camera space, -Z is forward. camSunDir.z < -0.05f means sun is in front
            if (camSunDir.z < -0.05f) {
                Matrix4f projToUse;
                if (hasCapturedProj) {
                    projToUse = capturedProj;
                } else {
                    float fov = (float) mc.options.fov().get();
                    if (mc.player != null) {
                        try {
                            fov *= mc.player.getFieldOfViewModifier();
                        } catch (Throwable ignored) {
                        }
                    }
                    float aspect = (float) viewWidth / (float) Math.max(1, viewHeight);
                    fallbackProj.identity().setPerspective((float) Math.toRadians(fov), aspect, 0.05f, 1000.0f);
                    projToUse = fallbackProj;
                }

                // Place sun at distance 100 in front of camera along the camera-space sun direction
                float dist = 100.0f;
                clipSun.set(camSunDir.x * dist, camSunDir.y * dist, camSunDir.z * dist, 1.0f);
                projToUse.transform(clipSun);

                if (clipSun.w > 0.001f) {
                    float ndcX = clipSun.x / clipSun.w;
                    float ndcY = clipSun.y / clipSun.w;

                    // Convert Normalized Device Coordinates [-1, 1] to Texture UV [0, 1]
                    screenX = 0.5f + 0.5f * ndcX;
                    screenY = 0.5f + 0.5f * ndcY;
                    sunInFront = 1.0f;
                } else {
                    resetCoordinates();
                }
            } else {
                // Sun is behind the camera: reset coordinates completely
                resetCoordinates();
            }
        } catch (Throwable ignored) {
            resetCoordinates();
        }
    }

    private void resetCoordinates() {
        screenX = 0.5f;
        screenY = 0.5f;
        sunInFront = 0.0f;
    }

    public float getScreenX() {
        return screenX;
    }

    public float getScreenY() {
        return screenY;
    }

    public float getSunInFront() {
        return sunInFront;
    }

    public float getHorizonFade() {
        return horizonFade;
    }

    public double getSunDirX() {
        return sunDirX;
    }

    public double getSunDirY() {
        return sunDirY;
    }

    public double getSunDirZ() {
        return sunDirZ;
    }
}
